# 🚀 Guía de Despliegue - CoachApp

## Desplegar en Vercel (Recomendado)

### ¿Por qué Vercel?
- ✅ **Gratis** para proyectos personales
- ✅ **Optimizado** para Next.js (misma empresa)
- ✅ **Automático**: Cada push a GitHub actualiza la app
- ✅ **Rápido**: Deploy en 2-3 minutos
- ✅ **HTTPS** y dominio incluidos
- ✅ **Sin configuración** adicional

### Pasos Detallados

#### 1. Preparar el Proyecto

Asegúrate de que tu proyecto tiene estos archivos (ya incluidos):
- ✅ `package.json`
- ✅ `next.config.js`
- ✅ `vercel.json`

#### 2. Subir a GitHub

```bash
# Navega a tu proyecto
cd coach-app

# Inicializa git (si no lo has hecho)
git init

# Añade todos los archivos
git add .

# Haz el primer commit
git commit -m "feat: CoachApp - Aplicación completa para entrenadores"

# Crea un repositorio en GitHub:
# 1. Ve a https://github.com
# 2. Click en el "+" arriba a la derecha
# 3. "New repository"
# 4. Nombre: "coach-app" (o el que quieras)
# 5. Puede ser público o privado
# 6. NO inicialices con README (ya lo tienes)
# 7. Click "Create repository"

# Conecta tu repo local con GitHub (usa la URL que te da GitHub)
git remote add origin https://github.com/TU_USUARIO/coach-app.git

# Sube tu código
git branch -M main
git push -u origin main
```

#### 3. Desplegar en Vercel

**Opción A: Desde el sitio web (Más fácil)**

1. Ve a [vercel.com](https://vercel.com)
2. Click en "Sign Up" (Regístrate con GitHub)
3. Autoriza a Vercel para acceder a tus repos
4. Click en "Add New..." → "Project"
5. Busca tu repositorio "coach-app"
6. Click en "Import"
7. Vercel detectará automáticamente Next.js
8. Click en "Deploy"
9. **¡Espera 2-3 minutos!**
10. ✅ Tu app estará en: `https://coach-app-XXXXX.vercel.app`

**Opción B: Desde la terminal (Avanzado)**

```bash
# Instala Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel

# Sigue las instrucciones en pantalla
```

#### 4. Configurar Dominio Personalizado (Opcional)

En el dashboard de Vercel:
1. Ve a tu proyecto
2. Settings → Domains
3. Añade tu dominio personalizado
4. Sigue las instrucciones para configurar DNS

---

## Desplegar en Netlify (Alternativa)

### Pasos

1. Sube a GitHub (mismo proceso que arriba)
2. Ve a [netlify.com](https://netlify.com)
3. "Sign up" con GitHub
4. "Add new site" → "Import an existing project"
5. Conecta con GitHub
6. Selecciona tu repo "coach-app"
7. **Build settings**:
   - Build command: `npm run build`
   - Publish directory: `.next`
8. Click "Deploy site"
9. Tu app estará en: `https://NOMBRE-RANDOM.netlify.app`

---

## ⚠️ Importante: localStorage

**Limitación actual**: La app usa localStorage, que es específico de cada navegador/dispositivo.

**Esto significa**:
- ✅ Los datos se guardan localmente
- ⚠️ Si cambias de navegador/dispositivo, pierdes los datos
- ⚠️ Si borras caché, pierdes los datos

**Soluciones futuras** (no incluidas en esta versión):
1. Añadir backend con base de datos (Firebase, Supabase)
2. Exportar/importar datos en JSON
3. Sincronización en la nube

---

## 🔄 Actualizar la App

Una vez desplegada, para actualizar:

```bash
# Haz tus cambios en el código
# ...

# Guarda cambios
git add .
git commit -m "feat: nueva funcionalidad"
git push

# Vercel/Netlify detectará el push y desplegará automáticamente
# ¡En 2-3 minutos estará actualizada!
```

---

## 🎯 URLs de Ejemplo

Después del despliegue tendrás algo como:

**Vercel**:
- `https://coach-app.vercel.app`
- `https://coach-app-git-main-tu-usuario.vercel.app`

**Netlify**:
- `https://coach-app-abc123.netlify.app`

Puedes personalizar el subdominio en los ajustes del proyecto.

---

## 🆓 Límites del Plan Gratuito

### Vercel Free
- ✅ Proyectos ilimitados
- ✅ Despliegues ilimitados
- ✅ 100 GB ancho de banda/mes
- ✅ Dominio personalizado
- ✅ HTTPS automático

### Netlify Free
- ✅ 100 GB ancho de banda/mes
- ✅ 300 minutos build/mes
- ✅ Proyectos ilimitados

**Para este proyecto, el plan gratuito es más que suficiente.**

---

## 🐛 Troubleshooting

### Error: "Command failed with exit code 1"
- Verifica que `npm run build` funcione localmente
- Revisa los logs en Vercel/Netlify

### La app no carga
- Verifica que la URL sea correcta
- Espera 2-3 minutos después del deploy
- Revisa la consola del navegador (F12)

### Datos no se guardan
- Recuerda: localStorage es local al navegador
- Cada usuario tendrá sus propios datos

---

## 📱 Compartir tu App

Una vez desplegada:

1. **Comparte la URL**: `https://tu-app.vercel.app`
2. **Usuarios pueden**:
   - Acceder desde cualquier dispositivo
   - Usar el modo demo
   - Guardar sus propios datos localmente
3. **Tú puedes**:
   - Actualizar código en GitHub
   - Los cambios se reflejan automáticamente
   - Ver estadísticas de uso en Vercel

---

## 🎓 Para tu Presentación

Puedes decir:

> "He desarrollado CoachApp, una aplicación web completa disponible en [URL]. 
> Está desplegada en la nube usando Vercel, con integración continua desde GitHub.
> Cualquier persona puede acceder desde su navegador, sin instalar nada."

¡Suena mucho más profesional! 🚀

---

## 📞 Ayuda

Si tienes problemas:
1. Revisa los logs en Vercel/Netlify
2. Verifica que el build funcione localmente
3. Consulta la documentación: [vercel.com/docs](https://vercel.com/docs)

---

¡Tu app estará accesible desde cualquier lugar del mundo! 🌍
