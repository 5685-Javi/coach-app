# CoachApp - Aplicación para Entrenadores de Fútbol

## 📋 Descripción

CoachApp es una aplicación web completa diseñada específicamente para entrenadores de fútbol formativo. Combina gestión táctica, seguimiento formativo, análisis psicológico y enfoque ético en una única herramienta integral.

**Proyecto desarrollado por Javi (13 años)** como parte de un proyecto escolar sobre IA y tecnología aplicada al deporte.

## 🎯 Filosofía

- **Formativo**: Priorizamos el desarrollo integral sobre los resultados inmediatos
- **Ético**: Protección del menor y uso responsable de datos
- **Reflexivo**: IA que ayuda a pensar, no que decide por ti
- **Práctico**: Soluciones reales para problemas del día a día

## ✨ Características Principales

### Gestión de Jugadores
- Ficha completa de cada jugador
- Seguimiento de minutos totales
- Control de asistencia a entrenamientos
- Registro de clima personal
- Identificación de roles invisibles
- Evaluación de riesgo de abandono
- Notas formativas individuales

### Convocatorias y Partidos
- Planificación de partidos y convocatorias
- Gestión de minutos por jugador
- Modo torneo para múltiples partidos
- Clasificación por tipo e importancia
- Análisis post-partido

### Entrenamientos
- Calendario de sesiones
- Objetivos tácticos y formativos
- Control de asistencia
- Relación con mesociclos y microciclos

### Clima y Conflictos
- Seguimiento del ambiente del equipo
- Registro de conflictos
- Estado y seguimiento de resolución
- Tendencias históricas

### Estadísticas y Alertas
- Panel de métricas clave
- Gráficos de minutos y posiciones
- Alertas automáticas:
  - Desequilibrio de minutos
  - Riesgo de abandono
  - Clima tenso
  - Asistencia baja
- Tablas detalladas por jugador

### IA Reflexiva
- Asistente que detecta patrones
- Preguntas para la reflexión
- Sugerencias constructivas
- NO toma decisiones por ti

### Diario del Entrenador
- Registro de aprendizajes
- Análisis según modelo T-F-P-E:
  - Táctico
  - Formativo
  - Psicológico
  - Ético
- Ciclo de mejora continua
- Decisiones difíciles documentadas

### Configuración
- Datos del equipo
- Criterios de minutos
- Parámetros de alertas
- Personalización

## 🛠️ Tecnologías

- **Framework**: Next.js 14 (React)
- **Lenguaje**: TypeScript
- **Estilos**: Tailwind CSS
- **Gráficos**: Recharts
- **Iconos**: React Icons
- **Almacenamiento**: localStorage (navegador)
- **Fechas**: date-fns

## 📦 Instalación

```bash
# Clonar o descargar el proyecto
cd coach-app

# Instalar dependencias
npm install

# Ejecutar en modo desarrollo
npm run dev

# Abrir en el navegador
# http://localhost:3000
```

## 🚀 Uso

1. **Inicio**: Accede a la página principal y conoce la filosofía de la app
2. **Login**: Usa el acceso demo para probar con datos de ejemplo
3. **Dashboard**: Vista general de tu equipo y próximas actividades
4. **Gestión**: Navega por los diferentes módulos según necesites

### Primer Uso

Al hacer login con el modo demo, se cargarán automáticamente:
- 5 jugadores de ejemplo
- Datos de equipo configurados
- Algunas alertas generadas

Puedes modificar, añadir o eliminar cualquier dato.

## 📱 Características Técnicas

### Arquitectura

```
coach-app/
├── app/                    # Páginas de Next.js
│   ├── dashboard/          # Dashboard principal
│   ├── players/            # Gestión de jugadores
│   ├── matches/            # Partidos y convocatorias
│   ├── trainings/          # Entrenamientos
│   ├── climate/            # Clima y conflictos
│   ├── stats/              # Estadísticas
│   ├── ai/                 # IA reflexiva
│   ├── journal/            # Diario del entrenador
│   └── settings/           # Configuración
├── components/             # Componentes reutilizables
│   ├── layout/             # Navbar, etc.
│   └── ui/                 # Componentes UI
├── lib/                    # Lógica de negocio
│   ├── types/              # Tipos TypeScript
│   ├── storage/            # Gestión de datos
│   └── utils/              # Funciones auxiliares
└── public/                 # Recursos estáticos
```

### Modelo de Datos

El sistema utiliza localStorage para persistencia con los siguientes tipos principales:

- **Player**: Jugadores con stats, clima y seguimiento
- **Match**: Partidos con convocatorias y minutos
- **Training**: Entrenamientos con objetivos
- **Conflict**: Conflictos y su resolución
- **ClimateRecord**: Registros de ambiente
- **JournalEntry**: Entradas del diario
- **Alert**: Alertas automáticas
- **Settings**: Configuración personalizada

### Generación de Alertas

El sistema genera alertas automáticas basadas en:
- Distribución de minutos vs media del equipo
- Nivel de riesgo de los jugadores
- Tendencias del clima del equipo
- Asistencia a entrenamientos

## 🎓 Modelo T-F-P-E

Todas las decisiones y análisis se pueden evaluar según cuatro dimensiones:

1. **Táctico**: Sistemas, posiciones, estrategia
2. **Formativo**: Desarrollo de habilidades y personas
3. **Psicológico**: Clima, confianza, motivación
4. **Ético**: Valores, justicia, respeto

Este modelo está integrado en el diario del entrenador y en la reflexión asistida por IA.

## 🔄 Ciclo de Mejora Continua

1. **Observar**: ¿Qué está pasando?
2. **Interpretar**: ¿Por qué está pasando?
3. **Decidir**: ¿Qué voy a hacer?
4. **Actuar**: Implementar la decisión
5. **Reflexionar**: ¿Qué he aprendido?

## 🔐 Privacidad y Ética

- Los datos se almacenan localmente en tu navegador
- No hay servidor externo ni envío de información
- Uso responsable de datos de menores
- Enfoque en el desarrollo, no en la comparación pública
- IA orientada a la reflexión, no al control

## 📝 Licencia

Proyecto educativo desarrollado por Javi, 13 años.

## 🤝 Créditos

- **Autor**: Javi
- **Edad**: 13 años
- **Contexto**: Proyecto escolar avanzado
- **Enfoque**: Tecnología + Deporte + Ética

## 📞 Notas

Esta es una aplicación de demostración y aprendizaje. Para uso en producción se recomendaría:

- Sistema de autenticación robusto
- Base de datos real (no localStorage)
- Backup y exportación de datos
- Integración con APIs de IA reales
- Testing completo
- Optimización de rendimiento
- Accesibilidad mejorada
- Internacionalización completa

---

**CoachApp** - Desarrollando personas, no solo jugadores 🏃⚽💚
