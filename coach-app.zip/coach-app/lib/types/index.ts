// lib/types/index.ts
// Tipos principales de la aplicación

export type UserRole = 'coach' | 'coordinator';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  teamId: string;
  clubId?: string;
}

export interface Player {
  id: string;
  name: string;
  birthDate: string;
  position: Position;
  shirtNumber: number;
  totalMinutes: number;
  trainingAttendance: number;
  climate: ClimateLevel;
  invisibleRoles: string[];
  notes: string;
  riskLevel: RiskLevel;
  teamId: string;
}

export type Position = 
  | 'Portero' 
  | 'Defensa' 
  | 'Centrocampista' 
  | 'Delantero';

export type ClimateLevel = 'muy-positivo' | 'positivo' | 'neutral' | 'tenso' | 'muy-tenso';
export type RiskLevel = 'ninguno' | 'bajo' | 'medio' | 'alto';

export interface Match {
  id: string;
  date: string;
  rival: string;
  type: MatchType;
  importance: ImportanceLevel;
  location: 'local' | 'visitante';
  result?: string;
  minutes: PlayerMinutes[];
  convocados: string[]; // Player IDs
  tournamentId?: string;
  teamId: string;
}

export type MatchType = 'amistoso' | 'liga' | 'torneo' | 'copa';
export type ImportanceLevel = 'baja' | 'media' | 'alta' | 'muy-alta';

export interface PlayerMinutes {
  playerId: string;
  minutes: number;
  position: Position;
}

export interface Training {
  id: string;
  date: string;
  objectives: TrainingObjectives;
  tasks: string[];
  attendance: string[]; // Player IDs
  microcycle?: string;
  mesocycle?: string;
  teamId: string;
}

export interface TrainingObjectives {
  tactical: string[];
  formative: string[];
  physical?: string[];
}

export interface Conflict {
  id: string;
  date: string;
  type: ConflictType;
  description: string;
  involved: string[]; // Player IDs or names
  status: ConflictStatus;
  resolution?: string;
  teamId: string;
}

export type ConflictType = 
  | 'disciplina' 
  | 'convivencia' 
  | 'familia' 
  | 'rendimiento' 
  | 'otro';

export type ConflictStatus = 'abierto' | 'en-seguimiento' | 'resuelto';

export interface ClimateRecord {
  id: string;
  date: string;
  level: ClimateLevel;
  notes: string;
  teamId: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  type: JournalType;
  title: string;
  content: string;
  analysis: TFPEAnalysis;
  improvementCycle: ImprovementCycleNote[];
  teamId: string;
}

export type JournalType = 'partido' | 'semana' | 'decision' | 'reflexion';

export interface TFPEAnalysis {
  tactical?: string;
  formative?: string;
  psychological?: string;
  ethical?: string;
}

export interface ImprovementCycleNote {
  phase: 'observar' | 'interpretar' | 'decidir' | 'actuar' | 'reflexionar';
  note: string;
}

export interface Alert {
  id: string;
  type: AlertType;
  severity: 'info' | 'warning' | 'critical';
  message: string;
  playerId?: string;
  date: string;
  resolved: boolean;
}

export type AlertType = 
  | 'minutos-desequilibrados' 
  | 'riesgo-abandono' 
  | 'clima-tenso' 
  | 'asistencia-baja'
  | 'conflicto-abierto';

export interface Tournament {
  id: string;
  name: string;
  date: string;
  matches: string[]; // Match IDs
  globalMinutesStrategy: string;
  teamId: string;
}

export interface Team {
  id: string;
  name: string;
  category: string;
  season: string;
  clubId: string;
  minMinutesTarget: number;
}

export interface Club {
  id: string;
  name: string;
  teams: string[]; // Team IDs
}

export interface AIReflection {
  id: string;
  date: string;
  query: string;
  response: string;
  suggestions: string[];
  teamId: string;
}

export interface Settings {
  teamData: {
    name: string;
    category: string;
    season: string;
  };
  minutesCriteria: {
    minMinutes: number;
    targetMinutes: number;
    considerImportance: boolean;
  };
  alerts: {
    minutesThreshold: number;
    attendanceThreshold: number;
    climateAlerts: boolean;
  };
  theme: 'light' | 'dark';
  language: 'es' | 'en';
}
