// lib/utils/index.ts
// Funciones de utilidad

import { format, parseISO } from 'date-fns';
import { es } from 'date-fns/locale';

export const formatDate = (date: string | Date): string => {
  try {
    const dateObj = typeof date === 'string' ? parseISO(date) : date;
    return format(dateObj, 'dd/MM/yyyy', { locale: es });
  } catch {
    return 'Fecha inválida';
  }
};

export const formatDateTime = (date: string | Date): string => {
  try {
    const dateObj = typeof date === 'string' ? parseISO(date) : date;
    return format(dateObj, 'dd/MM/yyyy HH:mm', { locale: es });
  } catch {
    return 'Fecha inválida';
  }
};

export const generateId = (): string => {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

export const getClimateColor = (level: string): string => {
  const colors: { [key: string]: string } = {
    'muy-positivo': 'text-green-600 bg-green-50',
    'positivo': 'text-green-500 bg-green-50',
    'neutral': 'text-gray-500 bg-gray-50',
    'tenso': 'text-orange-500 bg-orange-50',
    'muy-tenso': 'text-red-600 bg-red-50',
  };
  return colors[level] || 'text-gray-500 bg-gray-50';
};

export const getClimateLabel = (level: string): string => {
  const labels: { [key: string]: string } = {
    'muy-positivo': 'Muy Positivo',
    'positivo': 'Positivo',
    'neutral': 'Neutral',
    'tenso': 'Tenso',
    'muy-tenso': 'Muy Tenso',
  };
  return labels[level] || 'Desconocido';
};

export const getRiskColor = (level: string): string => {
  const colors: { [key: string]: string } = {
    'ninguno': 'text-green-600 bg-green-50',
    'bajo': 'text-yellow-600 bg-yellow-50',
    'medio': 'text-orange-600 bg-orange-50',
    'alto': 'text-red-600 bg-red-50',
  };
  return colors[level] || 'text-gray-500 bg-gray-50';
};

export const getRiskLabel = (level: string): string => {
  const labels: { [key: string]: string } = {
    'ninguno': 'Sin Riesgo',
    'bajo': 'Riesgo Bajo',
    'medio': 'Riesgo Medio',
    'alto': 'Riesgo Alto',
  };
  return labels[level] || 'Desconocido';
};

export const getAlertSeverityColor = (severity: string): string => {
  const colors: { [key: string]: string } = {
    'info': 'text-blue-600 bg-blue-50 border-blue-200',
    'warning': 'text-orange-600 bg-orange-50 border-orange-200',
    'critical': 'text-red-600 bg-red-50 border-red-200',
  };
  return colors[severity] || 'text-gray-500 bg-gray-50 border-gray-200';
};

export const calculateAge = (birthDate: string): number => {
  const birth = parseISO(birthDate);
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  return age;
};

export const getPositionColor = (position: string): string => {
  const colors: { [key: string]: string } = {
    'Portero': 'bg-yellow-100 text-yellow-800',
    'Defensa': 'bg-blue-100 text-blue-800',
    'Centrocampista': 'bg-green-100 text-green-800',
    'Delantero': 'bg-red-100 text-red-800',
  };
  return colors[position] || 'bg-gray-100 text-gray-800';
};

export const cn = (...classes: (string | boolean | undefined)[]): string => {
  return classes.filter(Boolean).join(' ');
};
