// lib/storage/index.ts
// Sistema de almacenamiento basado en localStorage

import { 
  Player, Match, Training, Conflict, ClimateRecord, 
  JournalEntry, Alert, Tournament, Team, User, Settings, AIReflection 
} from '@/lib/types';

const STORAGE_KEYS = {
  USER: 'coach_app_user',
  PLAYERS: 'coach_app_players',
  MATCHES: 'coach_app_matches',
  TRAININGS: 'coach_app_trainings',
  CONFLICTS: 'coach_app_conflicts',
  CLIMATE: 'coach_app_climate',
  JOURNAL: 'coach_app_journal',
  ALERTS: 'coach_app_alerts',
  TOURNAMENTS: 'coach_app_tournaments',
  TEAM: 'coach_app_team',
  SETTINGS: 'coach_app_settings',
  AI_REFLECTIONS: 'coach_app_ai_reflections',
};

// Utilidades genéricas
const getItem = <T>(key: string, defaultValue: T): T => {
  if (typeof window === 'undefined') return defaultValue;
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
};

const setItem = <T>(key: string, value: T): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
};

// User
export const getUser = (): User | null => getItem<User | null>(STORAGE_KEYS.USER, null);
export const setUser = (user: User | null): void => setItem(STORAGE_KEYS.USER, user);

// Players
export const getPlayers = (): Player[] => getItem<Player[]>(STORAGE_KEYS.PLAYERS, []);
export const setPlayers = (players: Player[]): void => setItem(STORAGE_KEYS.PLAYERS, players);
export const addPlayer = (player: Player): void => {
  const players = getPlayers();
  setPlayers([...players, player]);
};
export const updatePlayer = (id: string, data: Partial<Player>): void => {
  const players = getPlayers();
  const updated = players.map(p => p.id === id ? { ...p, ...data } : p);
  setPlayers(updated);
};
export const deletePlayer = (id: string): void => {
  const players = getPlayers();
  setPlayers(players.filter(p => p.id !== id));
};

// Matches
export const getMatches = (): Match[] => getItem<Match[]>(STORAGE_KEYS.MATCHES, []);
export const setMatches = (matches: Match[]): void => setItem(STORAGE_KEYS.MATCHES, matches);
export const addMatch = (match: Match): void => {
  const matches = getMatches();
  setMatches([...matches, match]);
};
export const updateMatch = (id: string, data: Partial<Match>): void => {
  const matches = getMatches();
  const updated = matches.map(m => m.id === id ? { ...m, ...data } : m);
  setMatches(updated);
};
export const deleteMatch = (id: string): void => {
  const matches = getMatches();
  setMatches(matches.filter(m => m.id !== id));
};

// Trainings
export const getTrainings = (): Training[] => getItem<Training[]>(STORAGE_KEYS.TRAININGS, []);
export const setTrainings = (trainings: Training[]): void => setItem(STORAGE_KEYS.TRAININGS, trainings);
export const addTraining = (training: Training): void => {
  const trainings = getTrainings();
  setTrainings([...trainings, training]);
};
export const updateTraining = (id: string, data: Partial<Training>): void => {
  const trainings = getTrainings();
  const updated = trainings.map(t => t.id === id ? { ...t, ...data } : t);
  setTrainings(updated);
};
export const deleteTraining = (id: string): void => {
  const trainings = getTrainings();
  setTrainings(trainings.filter(t => t.id !== id));
};

// Conflicts
export const getConflicts = (): Conflict[] => getItem<Conflict[]>(STORAGE_KEYS.CONFLICTS, []);
export const setConflicts = (conflicts: Conflict[]): void => setItem(STORAGE_KEYS.CONFLICTS, conflicts);
export const addConflict = (conflict: Conflict): void => {
  const conflicts = getConflicts();
  setConflicts([...conflicts, conflict]);
};
export const updateConflict = (id: string, data: Partial<Conflict>): void => {
  const conflicts = getConflicts();
  const updated = conflicts.map(c => c.id === id ? { ...c, ...data } : c);
  setConflicts(updated);
};
export const deleteConflict = (id: string): void => {
  const conflicts = getConflicts();
  setConflicts(conflicts.filter(c => c.id !== id));
};

// Climate Records
export const getClimateRecords = (): ClimateRecord[] => getItem<ClimateRecord[]>(STORAGE_KEYS.CLIMATE, []);
export const setClimateRecords = (records: ClimateRecord[]): void => setItem(STORAGE_KEYS.CLIMATE, records);
export const addClimateRecord = (record: ClimateRecord): void => {
  const records = getClimateRecords();
  setClimateRecords([...records, record]);
};

// Journal Entries
export const getJournalEntries = (): JournalEntry[] => getItem<JournalEntry[]>(STORAGE_KEYS.JOURNAL, []);
export const setJournalEntries = (entries: JournalEntry[]): void => setItem(STORAGE_KEYS.JOURNAL, entries);
export const addJournalEntry = (entry: JournalEntry): void => {
  const entries = getJournalEntries();
  setJournalEntries([...entries, entry]);
};
export const updateJournalEntry = (id: string, data: Partial<JournalEntry>): void => {
  const entries = getJournalEntries();
  const updated = entries.map(e => e.id === id ? { ...e, ...data } : e);
  setJournalEntries(updated);
};
export const deleteJournalEntry = (id: string): void => {
  const entries = getJournalEntries();
  setJournalEntries(entries.filter(e => e.id !== id));
};

// Alerts
export const getAlerts = (): Alert[] => getItem<Alert[]>(STORAGE_KEYS.ALERTS, []);
export const setAlerts = (alerts: Alert[]): void => setItem(STORAGE_KEYS.ALERTS, alerts);
export const addAlert = (alert: Alert): void => {
  const alerts = getAlerts();
  setAlerts([...alerts, alert]);
};
export const resolveAlert = (id: string): void => {
  const alerts = getAlerts();
  const updated = alerts.map(a => a.id === id ? { ...a, resolved: true } : a);
  setAlerts(updated);
};

// Tournaments
export const getTournaments = (): Tournament[] => getItem<Tournament[]>(STORAGE_KEYS.TOURNAMENTS, []);
export const setTournaments = (tournaments: Tournament[]): void => setItem(STORAGE_KEYS.TOURNAMENTS, tournaments);
export const addTournament = (tournament: Tournament): void => {
  const tournaments = getTournaments();
  setTournaments([...tournaments, tournament]);
};

// Team
export const getTeam = (): Team | null => getItem<Team | null>(STORAGE_KEYS.TEAM, null);
export const setTeam = (team: Team): void => setItem(STORAGE_KEYS.TEAM, team);

// Settings
export const getSettings = (): Settings => {
  const defaultSettings: Settings = {
    teamData: {
      name: 'Mi Equipo',
      category: 'Alevín',
      season: '2025-26',
    },
    minutesCriteria: {
      minMinutes: 20,
      targetMinutes: 45,
      considerImportance: true,
    },
    alerts: {
      minutesThreshold: 0.5,
      attendanceThreshold: 0.7,
      climateAlerts: true,
    },
    theme: 'light',
    language: 'es',
  };
  return getItem<Settings>(STORAGE_KEYS.SETTINGS, defaultSettings);
};
export const setSettings = (settings: Settings): void => setItem(STORAGE_KEYS.SETTINGS, settings);

// AI Reflections
export const getAIReflections = (): AIReflection[] => getItem<AIReflection[]>(STORAGE_KEYS.AI_REFLECTIONS, []);
export const setAIReflections = (reflections: AIReflection[]): void => setItem(STORAGE_KEYS.AI_REFLECTIONS, reflections);
export const addAIReflection = (reflection: AIReflection): void => {
  const reflections = getAIReflections();
  setAIReflections([...reflections, reflection]);
};

// Inicializar datos de ejemplo
export const initializeMockData = (): void => {
  const currentPlayers = getPlayers();
  if (currentPlayers.length === 0) {
    const mockPlayers: Player[] = [
      {
        id: '1',
        name: 'Carlos Méndez',
        birthDate: '2012-03-15',
        position: 'Portero',
        shirtNumber: 1,
        totalMinutes: 180,
        trainingAttendance: 0.95,
        climate: 'positivo',
        invisibleRoles: ['líder-silencioso', 'animador'],
        notes: 'Buen progreso en salidas. Trabajar confianza en uno contra uno.',
        riskLevel: 'ninguno',
        teamId: 'team-1',
      },
      {
        id: '2',
        name: 'Ana Rodríguez',
        birthDate: '2012-07-22',
        position: 'Defensa',
        shirtNumber: 4,
        totalMinutes: 210,
        trainingAttendance: 0.90,
        climate: 'muy-positivo',
        invisibleRoles: ['organizadora', 'mentora'],
        notes: 'Excelente lectura táctica. Referente defensivo del equipo.',
        riskLevel: 'ninguno',
        teamId: 'team-1',
      },
      {
        id: '3',
        name: 'Miguel Torres',
        birthDate: '2012-11-08',
        position: 'Centrocampista',
        shirtNumber: 8,
        totalMinutes: 150,
        trainingAttendance: 0.85,
        climate: 'neutral',
        climate: 'neutral',
        invisibleRoles: ['creativo', 'observador'],
        notes: 'Buena visión de juego. Necesita más confianza para reclamar balón.',
        riskLevel: 'bajo',
        teamId: 'team-1',
      },
      {
        id: '4',
        name: 'Laura Sánchez',
        birthDate: '2012-05-19',
        position: 'Delantero',
        shirtNumber: 9,
        totalMinutes: 190,
        trainingAttendance: 0.92,
        climate: 'positivo',
        invisibleRoles: ['competidora', 'referente'],
        notes: 'Gran capacidad goleadora. Trabajar juego asociativo.',
        riskLevel: 'ninguno',
        teamId: 'team-1',
      },
      {
        id: '5',
        name: 'David López',
        birthDate: '2012-09-30',
        position: 'Centrocampista',
        shirtNumber: 6,
        totalMinutes: 120,
        trainingAttendance: 0.75,
        climate: 'tenso',
        invisibleRoles: ['resiliente'],
        notes: 'Situación familiar complicada. Seguimiento cercano necesario.',
        riskLevel: 'medio',
        teamId: 'team-1',
      },
    ];
    setPlayers(mockPlayers);

    const mockTeam: Team = {
      id: 'team-1',
      name: 'CD Ejemplo - Alevín A',
      category: 'Alevín',
      season: '2025-26',
      clubId: 'club-1',
      minMinutesTarget: 20,
    };
    setTeam(mockTeam);
  }
};

// Función para generar alertas automáticamente
export const generateAlerts = (): void => {
  const players = getPlayers();
  const matches = getMatches();
  const climateRecords = getClimateRecords();
  const settings = getSettings();
  const newAlerts: Alert[] = [];

  // Alerta de minutos desequilibrados
  if (players.length > 0 && matches.length > 0) {
    const avgMinutes = players.reduce((sum, p) => sum + p.totalMinutes, 0) / players.length;
    players.forEach(player => {
      const ratio = player.totalMinutes / avgMinutes;
      if (ratio < settings.alerts.minutesThreshold) {
        newAlerts.push({
          id: `alert-minutes-${player.id}-${Date.now()}`,
          type: 'minutos-desequilibrados',
          severity: 'warning',
          message: `${player.name} tiene ${player.totalMinutes} minutos, muy por debajo de la media (${Math.round(avgMinutes)})`,
          playerId: player.id,
          date: new Date().toISOString(),
          resolved: false,
        });
      }
    });
  }

  // Alerta de riesgo de abandono
  players.forEach(player => {
    if (player.riskLevel === 'alto' || player.riskLevel === 'medio') {
      newAlerts.push({
        id: `alert-risk-${player.id}-${Date.now()}`,
        type: 'riesgo-abandono',
        severity: player.riskLevel === 'alto' ? 'critical' : 'warning',
        message: `${player.name} presenta riesgo ${player.riskLevel} de abandono. Asistencia: ${Math.round(player.trainingAttendance * 100)}%`,
        playerId: player.id,
        date: new Date().toISOString(),
        resolved: false,
      });
    }
  });

  // Alerta de clima tenso
  const recentClimate = climateRecords.slice(-3);
  const tenseLevels = recentClimate.filter(c => c.level === 'tenso' || c.level === 'muy-tenso');
  if (tenseLevels.length >= 2) {
    newAlerts.push({
      id: `alert-climate-${Date.now()}`,
      type: 'clima-tenso',
      severity: 'warning',
      message: 'El clima del equipo ha sido tenso en las últimas sesiones',
      date: new Date().toISOString(),
      resolved: false,
    });
  }

  const existingAlerts = getAlerts();
  const unresolvedAlerts = existingAlerts.filter(a => !a.resolved);
  setAlerts([...unresolvedAlerts, ...newAlerts]);
};
