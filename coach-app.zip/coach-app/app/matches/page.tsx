// app/matches/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { FaPlus, FaCalendarAlt, FaEdit, FaTrash } from 'react-icons/fa';
import { getMatches, addMatch, deleteMatch, getPlayers } from '@/lib/storage';
import { Match, MatchType, ImportanceLevel } from '@/lib/types';
import { generateId, formatDate } from '@/lib/utils';

export default function MatchesPage() {
  const router = useRouter();
  const [matches, setMatches] = useState<Match[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState<Partial<Match>>({
    date: '',
    rival: '',
    type: 'liga',
    importance: 'media',
    location: 'local',
    convocados: [],
    minutes: [],
    teamId: 'team-1',
  });

  useEffect(() => {
    loadMatches();
  }, []);

  const loadMatches = () => {
    const allMatches = getMatches();
    setMatches(allMatches.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };

  const handleOpenModal = () => {
    setFormData({
      date: '',
      rival: '',
      type: 'liga',
      importance: 'media',
      location: 'local',
      convocados: [],
      minutes: [],
      teamId: 'team-1',
    });
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newMatch: Match = {
      id: generateId(),
      ...formData as Match,
    };
    
    addMatch(newMatch);
    loadMatches();
    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (confirm('¿Eliminar este partido?')) {
      deleteMatch(id);
      loadMatches();
    }
  };

  const getMatchTypeColor = (type: MatchType) => {
    const colors = {
      'amistoso': 'bg-green-100 text-green-800',
      'liga': 'bg-blue-100 text-blue-800',
      'torneo': 'bg-purple-100 text-purple-800',
      'copa': 'bg-orange-100 text-orange-800',
    };
    return colors[type];
  };

  const getImportanceColor = (importance: ImportanceLevel) => {
    const colors = {
      'baja': 'bg-gray-100 text-gray-800',
      'media': 'bg-blue-100 text-blue-800',
      'alta': 'bg-orange-100 text-orange-800',
      'muy-alta': 'bg-red-100 text-red-800',
    };
    return colors[importance];
  };

  return (
    <div className="space-y-6 fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Partidos</h1>
          <p className="text-gray-600 mt-1">Gestiona convocatorias y seguimiento de encuentros</p>
        </div>
        <button onClick={handleOpenModal} className="btn btn-primary flex items-center gap-2">
          <FaPlus /> Nuevo Partido
        </button>
      </div>

      {matches.length > 0 ? (
        <div className="space-y-4">
          {matches.map((match) => (
            <div key={match.id} className="card-hover">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <FaCalendarAlt className="text-primary-600" />
                    <span className="text-sm text-gray-600">{formatDate(match.date)}</span>
                    <span className={`badge ${getMatchTypeColor(match.type)} text-xs`}>
                      {match.type}
                    </span>
                    <span className={`badge ${getImportanceColor(match.importance)} text-xs`}>
                      {match.importance}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-1">
                    {match.location === 'local' ? '🏠' : '✈️'} vs {match.rival}
                  </h3>
                  {match.result && (
                    <p className="text-sm text-gray-600">Resultado: {match.result}</p>
                  )}
                  <p className="text-sm text-gray-500 mt-2">
                    {match.convocados.length} convocados
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => router.push(`/matches/${match.id}`)}
                    className="btn btn-outline text-sm"
                  >
                    Ver detalles
                  </button>
                  <button
                    onClick={() => handleDelete(match.id)}
                    className="btn bg-red-50 text-red-600 hover:bg-red-100 text-sm"
                  >
                    <FaTrash />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center py-12">
          <p className="text-gray-500 mb-4">No hay partidos registrados</p>
          <button onClick={handleOpenModal} className="btn btn-primary inline-flex items-center gap-2">
            <FaPlus /> Crear primer partido
          </button>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Nuevo Partido</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fecha y hora *
                    </label>
                    <input
                      type="datetime-local"
                      value={formData.date}
                      onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                      required
                      className="input"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Rival *
                    </label>
                    <input
                      type="text"
                      value={formData.rival}
                      onChange={(e) => setFormData({ ...formData, rival: e.target.value })}
                      required
                      className="input"
                      placeholder="Nombre del equipo rival"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Tipo de partido *
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value as MatchType })}
                      className="select"
                    >
                      <option value="amistoso">Amistoso</option>
                      <option value="liga">Liga</option>
                      <option value="torneo">Torneo</option>
                      <option value="copa">Copa</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Importancia *
                    </label>
                    <select
                      value={formData.importance}
                      onChange={(e) => setFormData({ ...formData, importance: e.target.value as ImportanceLevel })}
                      className="select"
                    >
                      <option value="baja">Baja</option>
                      <option value="media">Media</option>
                      <option value="alta">Alta</option>
                      <option value="muy-alta">Muy Alta</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Ubicación *
                    </label>
                    <select
                      value={formData.location}
                      onChange={(e) => setFormData({ ...formData, location: e.target.value as 'local' | 'visitante' })}
                      className="select"
                    >
                      <option value="local">Local</option>
                      <option value="visitante">Visitante</option>
                    </select>
                  </div>
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 btn btn-primary">
                    Crear partido
                  </button>
                  <button type="button" onClick={handleCloseModal} className="flex-1 btn btn-outline">
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
