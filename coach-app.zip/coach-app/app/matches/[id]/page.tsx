// app/matches/[id]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { FaArrowLeft, FaUsers, FaClock } from 'react-icons/fa';
import { getMatches, getPlayers, updateMatch } from '@/lib/storage';
import { Match, Player, PlayerMinutes } from '@/lib/types';
import { formatDate } from '@/lib/utils';

export default function MatchDetailPage() {
  const router = useRouter();
  const params = useParams();
  const [match, setMatch] = useState<Match | null>(null);
  const [players, setPlayers] = useState<Player[]>([]);
  const [selectedPlayers, setSelectedPlayers] = useState<string[]>([]);
  const [minutes, setMinutes] = useState<{ [key: string]: number }>({});

  useEffect(() => {
    const matches = getMatches();
    const found = matches.find(m => m.id === params.id);
    if (found) {
      setMatch(found);
      setSelectedPlayers(found.convocados || []);
      const minutesMap: { [key: string]: number } = {};
      found.minutes.forEach(pm => {
        minutesMap[pm.playerId] = pm.minutes;
      });
      setMinutes(minutesMap);
    }
    setPlayers(getPlayers());
  }, [params.id]);

  const handleTogglePlayer = (playerId: string) => {
    if (selectedPlayers.includes(playerId)) {
      setSelectedPlayers(selectedPlayers.filter(id => id !== playerId));
      const newMinutes = { ...minutes };
      delete newMinutes[playerId];
      setMinutes(newMinutes);
    } else {
      setSelectedPlayers([...selectedPlayers, playerId]);
      setMinutes({ ...minutes, [playerId]: 0 });
    }
  };

  const handleMinutesChange = (playerId: string, value: number) => {
    setMinutes({ ...minutes, [playerId]: Math.max(0, Math.min(90, value)) });
  };

  const handleSave = () => {
    if (!match) return;
    
    const playerMinutes: PlayerMinutes[] = selectedPlayers.map(playerId => {
      const player = players.find(p => p.id === playerId);
      return {
        playerId,
        minutes: minutes[playerId] || 0,
        position: player?.position || 'Centrocampista',
      };
    });

    updateMatch(match.id, {
      convocados: selectedPlayers,
      minutes: playerMinutes,
    });

    alert('Convocatoria guardada');
    router.push('/matches');
  };

  if (!match) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Partido no encontrado</p>
        <button onClick={() => router.push('/matches')} className="mt-4 btn btn-primary">
          Volver a partidos
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center gap-4">
        <button onClick={() => router.push('/matches')} className="btn btn-outline">
          <FaArrowLeft />
        </button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900">vs {match.rival}</h1>
          <p className="text-gray-600">{formatDate(match.date)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="font-bold text-gray-900 mb-3">Información</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Tipo:</span>
              <span className="font-semibold">{match.type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Importancia:</span>
              <span className="font-semibold">{match.importance}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ubicación:</span>
              <span className="font-semibold">{match.location === 'local' ? 'Local' : 'Visitante'}</span>
            </div>
            {match.result && (
              <div className="flex justify-between">
                <span className="text-gray-600">Resultado:</span>
                <span className="font-semibold">{match.result}</span>
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <h3 className="font-bold text-gray-900 mb-3">Convocatoria</h3>
          <div className="flex items-center gap-3">
            <FaUsers className="text-2xl text-primary-600" />
            <div>
              <p className="text-3xl font-bold text-gray-900">{selectedPlayers.length}</p>
              <p className="text-sm text-gray-600">jugadores</p>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="font-bold text-gray-900 mb-3">Minutos Totales</h3>
          <div className="flex items-center gap-3">
            <FaClock className="text-2xl text-blue-600" />
            <div>
              <p className="text-3xl font-bold text-gray-900">
                {Object.values(minutes).reduce((sum, m) => sum + m, 0)}'
              </p>
              <p className="text-sm text-gray-600">asignados</p>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Gestión de Convocatoria y Minutos</h2>
        
        <div className="space-y-3">
          {players.map((player) => {
            const isSelected = selectedPlayers.includes(player.id);
            return (
              <div key={player.id} className={`p-4 rounded-lg border-2 transition-all ${
                isSelected ? 'border-primary-500 bg-primary-50' : 'border-gray-200 bg-gray-50'
              }`}>
                <div className="flex items-center gap-4">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => handleTogglePlayer(player.id)}
                    className="w-5 h-5 text-primary-600"
                  />
                  
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{player.name}</p>
                    <p className="text-sm text-gray-600">
                      {player.position} - #{player.shirtNumber}
                    </p>
                  </div>

                  {isSelected && (
                    <div className="flex items-center gap-2">
                      <label className="text-sm text-gray-700">Minutos:</label>
                      <input
                        type="number"
                        value={minutes[player.id] || 0}
                        onChange={(e) => handleMinutesChange(player.id, parseInt(e.target.value) || 0)}
                        min="0"
                        max="90"
                        className="input w-20 text-center"
                      />
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex gap-3">
          <button onClick={handleSave} className="btn btn-primary flex-1">
            Guardar Convocatoria
          </button>
          <button onClick={() => router.push('/matches')} className="btn btn-outline flex-1">
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}
