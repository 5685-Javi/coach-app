// app/ai/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { FaBrain, FaPaperPlane, FaLightbulb } from 'react-icons/fa';
import { getAIReflections, addAIReflection, getPlayers, getMatches } from '@/lib/storage';
import { AIReflection } from '@/lib/types';
import { generateId, formatDateTime } from '@/lib/utils';

export default function AIPage() {
  const [reflections, setReflections] = useState<AIReflection[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadReflections();
  }, []);

  const loadReflections = () => {
    const all = getAIReflections();
    setReflections(all.slice(-10).reverse());
  };

  // Simulación de IA con lógica local
  const simulateAIResponse = (userQuery: string): { response: string; suggestions: string[] } => {
    const players = getPlayers();
    const matches = getMatches();
    
    const lowerQuery = userQuery.toLowerCase();
    
    // Detectar patrones
    if (lowerQuery.includes('minutos') || lowerQuery.includes('juegan')) {
      const avgMinutes = players.reduce((sum, p) => sum + p.totalMinutes, 0) / players.length;
      const lowMinutesPlayers = players.filter(p => p.totalMinutes < avgMinutes * 0.5);
      
      return {
        response: lowMinutesPlayers.length > 0
          ? `He detectado que ${lowMinutesPlayers.length} jugadores tienen significativamente menos minutos que la media (${Math.round(avgMinutes)}'). ¿Has considerado las razones? ¿Es una decisión consciente basada en el desarrollo, o hay otros factores?`
          : `La distribución de minutos parece equilibrada. La media es ${Math.round(avgMinutes)}' por jugador.`,
        suggestions: [
          '¿Qué criterios estás usando para dar minutos?',
          '¿Cómo afecta la importancia del partido a tus decisiones?',
          '¿Estás considerando el desarrollo a largo plazo de cada jugador?',
        ],
      };
    }
    
    if (lowerQuery.includes('clima') || lowerQuery.includes('ambiente')) {
      const tensoPlayers = players.filter(p => p.climate === 'tenso' || p.climate === 'muy-tenso');
      return {
        response: tensoPlayers.length > 0
          ? `${tensoPlayers.length} jugadores muestran un clima tenso: ${tensoPlayers.map(p => p.name).join(', ')}. ¿Has hablado con ellos recientemente? A veces una conversación individual puede revelar preocupaciones que no son visibles en el grupo.`
          : 'El clima general del equipo parece positivo. ¿Qué prácticas estás usando para mantenerlo?',
        suggestions: [
          '¿Cuándo fue la última vez que hablaste individualmente con cada jugador?',
          '¿Hay situaciones familiares o escolares que puedan estar afectando?',
          '¿El grupo está cohesionado o hay subgrupos?',
        ],
      };
    }
    
    if (lowerQuery.includes('riesgo') || lowerQuery.includes('abandono')) {
      const riskPlayers = players.filter(p => p.riskLevel === 'medio' || p.riskLevel === 'alto');
      return {
        response: riskPlayers.length > 0
          ? `Hay ${riskPlayers.length} jugadores en riesgo de abandono. Los factores más comunes son: poco tiempo de juego, conflictos no resueltos, o situaciones familiares. ¿Qué plan de seguimiento tienes para cada uno?`
          : 'No hay jugadores en riesgo alto de abandono actualmente.',
        suggestions: [
          '¿Están recibiendo feedback positivo regularmente?',
          '¿Se sienten parte importante del equipo?',
          '¿Hay canales abiertos de comunicación con las familias?',
        ],
      };
    }
    
    // Respuesta genérica reflexiva
    return {
      response: 'Esa es una buena pregunta para reflexionar. En lugar de darte una respuesta directa, te invito a pensar: ¿Qué evidencias tienes? ¿Qué valores están en juego en esta decisión? ¿Cómo se alinea con tu visión formativa a largo plazo?',
      suggestions: [
        '¿Has consultado con otros entrenadores o mentores?',
        '¿Qué diría un observador externo sobre esta situación?',
        '¿Cómo te sentirías si esta fuera tu decisión en retrospectiva dentro de un año?',
      ],
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    
    // Simular delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const { response, suggestions } = simulateAIResponse(query);
    
    const reflection: AIReflection = {
      id: generateId(),
      date: new Date().toISOString(),
      query: query,
      response: response,
      suggestions: suggestions,
      teamId: 'team-1',
    };
    
    addAIReflection(reflection);
    loadReflections();
    setQuery('');
    setLoading(false);
  };

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Asistente de IA Reflexiva</h1>
        <p className="text-gray-600">
          Este asistente te ayuda a pensar mejor, no a decidir por ti. Hazle preguntas sobre tu equipo y recibe reflexiones constructivas.
        </p>
      </div>

      {/* Información importante */}
      <div className="card bg-blue-50 border-2 border-blue-200">
        <div className="flex items-start gap-3">
          <FaLightbulb className="text-2xl text-blue-600 mt-1" />
          <div>
            <h3 className="font-bold text-blue-900 mb-2">Enfoque Reflexivo</h3>
            <p className="text-sm text-blue-800">
              Esta IA no te da órdenes ni decide por ti. Su propósito es detectar patrones, hacerte preguntas y ayudarte a reflexionar sobre tus decisiones desde una perspectiva formativa y ética.
            </p>
          </div>
        </div>
      </div>

      {/* Formulario de consulta */}
      <div className="card">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Nueva Consulta</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              rows={4}
              className="textarea"
              placeholder="Ej: ¿Cómo puedo mejorar la distribución de minutos? ¿Qué hacer con el clima tenso del equipo?"
              disabled={loading}
            />
          </div>
          <button 
            type="submit" 
            disabled={loading || !query.trim()}
            className="btn btn-primary flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>Analizando...</>
            ) : (
              <>
                <FaPaperPlane /> Consultar
              </>
            )}
          </button>
        </form>
      </div>

      {/* Historial de reflexiones */}
      <div className="card">
        <div className="flex items-center gap-2 mb-6">
          <FaBrain className="text-2xl text-purple-600" />
          <h2 className="text-xl font-bold text-gray-900">Historial de Reflexiones</h2>
        </div>

        {reflections.length > 0 ? (
          <div className="space-y-6">
            {reflections.map((reflection) => (
              <div key={reflection.id} className="border-l-4 border-purple-500 pl-4 py-2">
                <p className="text-xs text-gray-500 mb-2">{formatDateTime(reflection.date)}</p>
                
                <div className="mb-4">
                  <p className="text-sm font-semibold text-gray-700 mb-2">Tu pregunta:</p>
                  <p className="text-gray-900">{reflection.query}</p>
                </div>
                
                <div className="mb-4 bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm font-semibold text-purple-900 mb-2">Reflexión:</p>
                  <p className="text-purple-900">{reflection.response}</p>
                </div>
                
                {reflection.suggestions.length > 0 && (
                  <div>
                    <p className="text-sm font-semibold text-gray-700 mb-2">Preguntas para reflexionar:</p>
                    <ul className="list-disc list-inside space-y-1">
                      {reflection.suggestions.map((suggestion, idx) => (
                        <li key={idx} className="text-sm text-gray-600">{suggestion}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">
            Aún no has hecho ninguna consulta. ¡Empieza haciendo una pregunta arriba!
          </p>
        )}
      </div>

      {/* Sugerencias de preguntas */}
      <div className="card bg-gray-50">
        <h3 className="font-bold text-gray-900 mb-3">Ejemplos de preguntas útiles:</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li>• ¿Cómo está la distribución de minutos en mi equipo?</li>
          <li>• ¿Hay jugadores con riesgo de abandono?</li>
          <li>• ¿Cómo está el clima del equipo?</li>
          <li>• ¿Qué patrones ves en mis decisiones recientes?</li>
          <li>• ¿Estoy equilibrando resultado y desarrollo?</li>
        </ul>
      </div>
    </div>
  );
}
