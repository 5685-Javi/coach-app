// app/settings/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { FaSave, FaCog } from 'react-icons/fa';
import { getSettings, setSettings, getTeam, setTeam } from '@/lib/storage';
import { Settings, Team } from '@/lib/types';

export default function SettingsPage() {
  const [settings, setSettingsState] = useState<Settings | null>(null);
  const [team, setTeamState] = useState<Team | null>(null);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const currentSettings = getSettings();
    const currentTeam = getTeam();
    setSettingsState(currentSettings);
    setTeamState(currentTeam);
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (settings) {
      setSettings(settings);
    }
    if (team) {
      setTeam(team);
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  if (!settings || !team) {
    return <div className="text-center py-12">Cargando configuración...</div>;
  }

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Ajustes</h1>
        <p className="text-gray-600 mt-1">Configura los parámetros de tu equipo y la aplicación</p>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Datos del equipo */}
        <div className="card">
          <div className="flex items-center gap-2 mb-6">
            <FaCog className="text-2xl text-primary-600" />
            <h2 className="text-xl font-bold text-gray-900">Datos del Equipo</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre del equipo *
              </label>
              <input
                type="text"
                value={team.name}
                onChange={(e) => setTeamState({ ...team, name: e.target.value })}
                required
                className="input"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Categoría *
              </label>
              <select
                value={team.category}
                onChange={(e) => setTeamState({ ...team, category: e.target.value })}
                className="select"
              >
                <option value="Prebenjamín">Prebenjamín</option>
                <option value="Benjamín">Benjamín</option>
                <option value="Alevín">Alevín</option>
                <option value="Infantil">Infantil</option>
                <option value="Cadete">Cadete</option>
                <option value="Juvenil">Juvenil</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Temporada *
              </label>
              <input
                type="text"
                value={team.season}
                onChange={(e) => setTeamState({ ...team, season: e.target.value })}
                required
                className="input"
                placeholder="Ej: 2025-26"
              />
            </div>
          </div>
        </div>

        {/* Criterios de minutos */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Criterios de Minutos</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Minutos mínimos objetivo (por jugador y partido)
              </label>
              <input
                type="number"
                value={settings.minutesCriteria.minMinutes}
                onChange={(e) => setSettingsState({
                  ...settings,
                  minutesCriteria: { ...settings.minutesCriteria, minMinutes: parseInt(e.target.value) }
                })}
                min="0"
                max="90"
                className="input"
              />
              <p className="text-xs text-gray-500 mt-1">
                Este es el mínimo que intentas dar a cada jugador convocado
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Minutos objetivo ideal
              </label>
              <input
                type="number"
                value={settings.minutesCriteria.targetMinutes}
                onChange={(e) => setSettingsState({
                  ...settings,
                  minutesCriteria: { ...settings.minutesCriteria, targetMinutes: parseInt(e.target.value) }
                })}
                min="0"
                max="90"
                className="input"
              />
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="considerImportance"
                checked={settings.minutesCriteria.considerImportance}
                onChange={(e) => setSettingsState({
                  ...settings,
                  minutesCriteria: { ...settings.minutesCriteria, considerImportance: e.target.checked }
                })}
                className="w-4 h-4 text-primary-600"
              />
              <label htmlFor="considerImportance" className="text-sm text-gray-700">
                Considerar la importancia del partido en la distribución de minutos
              </label>
            </div>
          </div>
        </div>

        {/* Alertas */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Configuración de Alertas</h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Umbral de minutos para alerta (% de la media)
              </label>
              <input
                type="number"
                value={settings.alerts.minutesThreshold}
                onChange={(e) => setSettingsState({
                  ...settings,
                  alerts: { ...settings.alerts, minutesThreshold: parseFloat(e.target.value) }
                })}
                min="0"
                max="1"
                step="0.1"
                className="input"
              />
              <p className="text-xs text-gray-500 mt-1">
                Genera alerta si un jugador tiene menos de este % de la media (ej: 0.5 = 50%)
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Umbral de asistencia para alerta (%)
              </label>
              <input
                type="number"
                value={settings.alerts.attendanceThreshold}
                onChange={(e) => setSettingsState({
                  ...settings,
                  alerts: { ...settings.alerts, attendanceThreshold: parseFloat(e.target.value) }
                })}
                min="0"
                max="1"
                step="0.1"
                className="input"
              />
              <p className="text-xs text-gray-500 mt-1">
                Genera alerta si la asistencia cae por debajo de este % (ej: 0.7 = 70%)
              </p>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="climateAlerts"
                checked={settings.alerts.climateAlerts}
                onChange={(e) => setSettingsState({
                  ...settings,
                  alerts: { ...settings.alerts, climateAlerts: e.target.checked }
                })}
                className="w-4 h-4 text-primary-600"
              />
              <label htmlFor="climateAlerts" className="text-sm text-gray-700">
                Activar alertas de clima del equipo
              </label>
            </div>
          </div>
        </div>

        {/* Botón guardar */}
        <div className="flex justify-end gap-3">
          {saved && (
            <div className="text-green-600 font-medium flex items-center gap-2">
              ✓ Configuración guardada
            </div>
          )}
          <button type="submit" className="btn btn-primary flex items-center gap-2">
            <FaSave /> Guardar Cambios
          </button>
        </div>
      </form>

      {/* Información adicional */}
      <div className="card bg-blue-50 border-2 border-blue-200">
        <h3 className="font-bold text-blue-900 mb-2">Sobre la configuración</h3>
        <p className="text-sm text-blue-800">
          Estos ajustes te ayudan a personalizar la app según tu filosofía y necesidades. Los criterios de minutos y alertas son orientativos y flexibles - la decisión final siempre es tuya como entrenador.
        </p>
      </div>
    </div>
  );
}
