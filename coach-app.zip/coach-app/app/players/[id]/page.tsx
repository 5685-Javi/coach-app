// app/players/[id]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { FaArrowLeft, FaEdit } from 'react-icons/fa';
import { getPlayers } from '@/lib/storage';
import { Player } from '@/lib/types';
import { formatDate, calculateAge, getPositionColor, getClimateColor, getRiskColor } from '@/lib/utils';

export default function PlayerDetailPage() {
  const router = useRouter();
  const params = useParams();
  const [player, setPlayer] = useState<Player | null>(null);

  useEffect(() => {
    const players = getPlayers();
    const found = players.find(p => p.id === params.id);
    if (found) {
      setPlayer(found);
    }
  }, [params.id]);

  if (!player) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Jugador no encontrado</p>
        <button onClick={() => router.push('/players')} className="mt-4 btn btn-primary">
          Volver a jugadores
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button onClick={() => router.push('/players')} className="btn btn-outline">
          <FaArrowLeft />
        </button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900">{player.name}</h1>
          <p className="text-gray-600">Dorsal #{player.shirtNumber}</p>
        </div>
        <button onClick={() => router.push('/players')} className="btn btn-secondary flex items-center gap-2">
          <FaEdit /> Editar
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Información básica */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Información Básica</h2>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Edad</p>
              <p className="font-semibold">{calculateAge(player.birthDate)} años</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Fecha de nacimiento</p>
              <p className="font-semibold">{formatDate(player.birthDate)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Posición</p>
              <span className={`badge ${getPositionColor(player.position)}`}>
                {player.position}
              </span>
            </div>
          </div>
        </div>

        {/* Estadísticas */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Estadísticas</h2>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600">Minutos totales</p>
              <p className="text-2xl font-bold text-primary-600">{player.totalMinutes}'</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Asistencia a entrenos</p>
              <p className="text-2xl font-bold text-green-600">
                {Math.round(player.trainingAttendance * 100)}%
              </p>
            </div>
          </div>
        </div>

        {/* Estado y clima */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Estado Actual</h2>
          <div className="space-y-3">
            <div>
              <p className="text-sm text-gray-600 mb-2">Clima</p>
              <span className={`badge ${getClimateColor(player.climate)} text-base px-4 py-2`}>
                {player.climate}
              </span>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-2">Nivel de riesgo</p>
              <span className={`badge ${getRiskColor(player.riskLevel)} text-base px-4 py-2`}>
                {player.riskLevel}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Roles invisibles */}
      {player.invisibleRoles && player.invisibleRoles.length > 0 && (
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Roles Invisibles</h2>
          <div className="flex flex-wrap gap-2">
            {player.invisibleRoles.map((role, index) => (
              <span key={index} className="badge bg-purple-100 text-purple-800 px-4 py-2">
                {role}
              </span>
            ))}
          </div>
          <p className="text-sm text-gray-600 mt-3">
            Los roles invisibles son cualidades no tácticas que aporta al equipo
          </p>
        </div>
      )}

      {/* Notas formativas */}
      {player.notes && (
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Notas Formativas</h2>
          <p className="text-gray-700 whitespace-pre-wrap">{player.notes}</p>
        </div>
      )}
    </div>
  );
}
