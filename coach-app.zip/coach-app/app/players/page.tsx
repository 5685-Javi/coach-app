// app/players/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { FaPlus, FaEdit, FaTrash, FaEye } from 'react-icons/fa';
import { getPlayers, addPlayer, updatePlayer, deletePlayer } from '@/lib/storage';
import { Player, Position, ClimateLevel, RiskLevel } from '@/lib/types';
import { generateId, getPositionColor, getClimateColor, getRiskColor } from '@/lib/utils';

export default function PlayersPage() {
  const router = useRouter();
  const [players, setPlayers] = useState<Player[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState<Player | null>(null);
  const [formData, setFormData] = useState<Partial<Player>>({
    name: '',
    birthDate: '',
    position: 'Centrocampista',
    shirtNumber: 1,
    totalMinutes: 0,
    trainingAttendance: 1,
    climate: 'neutral',
    invisibleRoles: [],
    notes: '',
    riskLevel: 'ninguno',
    teamId: 'team-1',
  });

  useEffect(() => {
    loadPlayers();
  }, []);

  const loadPlayers = () => {
    const allPlayers = getPlayers();
    setPlayers(allPlayers);
  };

  const handleOpenModal = (player?: Player) => {
    if (player) {
      setEditingPlayer(player);
      setFormData(player);
    } else {
      setEditingPlayer(null);
      setFormData({
        name: '',
        birthDate: '',
        position: 'Centrocampista',
        shirtNumber: 1,
        totalMinutes: 0,
        trainingAttendance: 1,
        climate: 'neutral',
        invisibleRoles: [],
        notes: '',
        riskLevel: 'ninguno',
        teamId: 'team-1',
      });
    }
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setEditingPlayer(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingPlayer) {
      updatePlayer(editingPlayer.id, formData);
    } else {
      const newPlayer: Player = {
        id: generateId(),
        ...formData as Player,
      };
      addPlayer(newPlayer);
    }
    
    loadPlayers();
    handleCloseModal();
  };

  const handleDelete = (id: string) => {
    if (confirm('¿Estás seguro de eliminar este jugador?')) {
      deletePlayer(id);
      loadPlayers();
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'shirtNumber' || name === 'totalMinutes' || name === 'trainingAttendance'
        ? parseFloat(value)
        : value,
    }));
  };

  return (
    <div className="space-y-6 fade-in">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Jugadores</h1>
          <p className="text-gray-600 mt-1">Gestiona tu plantilla y seguimiento individual</p>
        </div>
        <button
          onClick={() => handleOpenModal()}
          className="btn btn-primary flex items-center gap-2"
        >
          <FaPlus /> Añadir Jugador
        </button>
      </div>

      {/* Lista de jugadores */}
      {players.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {players.map((player) => (
            <div key={player.id} className="card-hover">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold text-gray-900">{player.name}</h3>
                  <p className="text-sm text-gray-600">#{player.shirtNumber}</p>
                </div>
                <span className={`badge ${getPositionColor(player.position)}`}>
                  {player.position}
                </span>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Minutos totales:</span>
                  <span className="font-semibold">{player.totalMinutes}'</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Asistencia:</span>
                  <span className="font-semibold">{Math.round(player.trainingAttendance * 100)}%</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Clima:</span>
                  <span className={`badge ${getClimateColor(player.climate)}`}>
                    {player.climate}
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Riesgo:</span>
                  <span className={`badge ${getRiskColor(player.riskLevel)}`}>
                    {player.riskLevel}
                  </span>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => router.push(`/players/${player.id}`)}
                  className="flex-1 btn btn-outline text-sm flex items-center justify-center gap-1"
                >
                  <FaEye /> Ver
                </button>
                <button
                  onClick={() => handleOpenModal(player)}
                  className="flex-1 btn bg-blue-50 text-blue-600 hover:bg-blue-100 text-sm flex items-center justify-center gap-1"
                >
                  <FaEdit /> Editar
                </button>
                <button
                  onClick={() => handleDelete(player.id)}
                  className="btn bg-red-50 text-red-600 hover:bg-red-100 text-sm"
                >
                  <FaTrash />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center py-12">
          <p className="text-gray-500 mb-4">No hay jugadores registrados</p>
          <button
            onClick={() => handleOpenModal()}
            className="btn btn-primary inline-flex items-center gap-2"
          >
            <FaPlus /> Añadir primer jugador
          </button>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                {editingPlayer ? 'Editar Jugador' : 'Nuevo Jugador'}
              </h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nombre completo *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="input"
                      placeholder="Ej: Carlos Méndez"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Fecha de nacimiento *
                    </label>
                    <input
                      type="date"
                      name="birthDate"
                      value={formData.birthDate}
                      onChange={handleChange}
                      required
                      className="input"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Posición *
                    </label>
                    <select
                      name="position"
                      value={formData.position}
                      onChange={handleChange}
                      required
                      className="select"
                    >
                      <option value="Portero">Portero</option>
                      <option value="Defensa">Defensa</option>
                      <option value="Centrocampista">Centrocampista</option>
                      <option value="Delantero">Delantero</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Dorsal *
                    </label>
                    <input
                      type="number"
                      name="shirtNumber"
                      value={formData.shirtNumber}
                      onChange={handleChange}
                      required
                      min="1"
                      max="99"
                      className="input"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Clima actual
                    </label>
                    <select
                      name="climate"
                      value={formData.climate}
                      onChange={handleChange}
                      className="select"
                    >
                      <option value="muy-positivo">Muy Positivo</option>
                      <option value="positivo">Positivo</option>
                      <option value="neutral">Neutral</option>
                      <option value="tenso">Tenso</option>
                      <option value="muy-tenso">Muy Tenso</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nivel de riesgo
                    </label>
                    <select
                      name="riskLevel"
                      value={formData.riskLevel}
                      onChange={handleChange}
                      className="select"
                    >
                      <option value="ninguno">Sin Riesgo</option>
                      <option value="bajo">Riesgo Bajo</option>
                      <option value="medio">Riesgo Medio</option>
                      <option value="alto">Riesgo Alto</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Notas formativas
                  </label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    rows={3}
                    className="textarea"
                    placeholder="Observaciones sobre su desarrollo, aspectos a trabajar, etc."
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 btn btn-primary">
                    {editingPlayer ? 'Guardar cambios' : 'Crear jugador'}
                  </button>
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    className="flex-1 btn btn-outline"
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
