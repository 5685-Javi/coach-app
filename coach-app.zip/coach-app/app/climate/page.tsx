// app/climate/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { FaPlus, FaCloudSun, FaExclamationTriangle } from 'react-icons/fa';
import { getClimateRecords, getConflicts, addClimateRecord, addConflict } from '@/lib/storage';
import { ClimateRecord, Conflict, ClimateLevel, ConflictType } from '@/lib/types';
import { generateId, formatDate, getClimateColor } from '@/lib/utils';

export default function ClimatePage() {
  const [climateRecords, setClimateRecords] = useState<ClimateRecord[]>([]);
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [showClimateModal, setShowClimateModal] = useState(false);
  const [showConflictModal, setShowConflictModal] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setClimateRecords(getClimateRecords().slice(-10).reverse());
    setConflicts(getConflicts().filter(c => c.status !== 'resuelto').slice(0, 10));
  };

  const handleAddClimate = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const record: ClimateRecord = {
      id: generateId(),
      date: new Date().toISOString(),
      level: formData.get('level') as ClimateLevel,
      notes: formData.get('notes') as string,
      teamId: 'team-1',
    };
    
    addClimateRecord(record);
    loadData();
    setShowClimateModal(false);
    form.reset();
  };

  const handleAddConflict = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const conflict: Conflict = {
      id: generateId(),
      date: new Date().toISOString(),
      type: formData.get('type') as ConflictType,
      description: formData.get('description') as string,
      involved: (formData.get('involved') as string).split(',').map(s => s.trim()),
      status: 'abierto',
      teamId: 'team-1',
    };
    
    addConflict(conflict);
    loadData();
    setShowConflictModal(false);
    form.reset();
  };

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Clima y Conflictos</h1>
        <p className="text-gray-600 mt-1">Seguimiento del ambiente y situaciones del equipo</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Clima del equipo */}
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <FaCloudSun className="text-2xl text-primary-600" />
              <h2 className="text-xl font-bold text-gray-900">Clima del Equipo</h2>
            </div>
            <button onClick={() => setShowClimateModal(true)} className="btn btn-primary btn-sm">
              <FaPlus />
            </button>
          </div>

          {climateRecords.length > 0 ? (
            <div className="space-y-3">
              {climateRecords.map((record) => (
                <div key={record.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <span className={`badge ${getClimateColor(record.level)}`}>
                      {record.level}
                    </span>
                    <span className="text-xs text-gray-500">{formatDate(record.date)}</span>
                  </div>
                  {record.notes && <p className="text-sm text-gray-700">{record.notes}</p>}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">No hay registros de clima</p>
          )}
        </div>

        {/* Conflictos */}
        <div className="card">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <FaExclamationTriangle className="text-2xl text-orange-600" />
              <h2 className="text-xl font-bold text-gray-900">Conflictos Activos</h2>
            </div>
            <button onClick={() => setShowConflictModal(true)} className="btn btn-primary btn-sm">
              <FaPlus />
            </button>
          </div>

          {conflicts.length > 0 ? (
            <div className="space-y-3">
              {conflicts.map((conflict) => (
                <div key={conflict.id} className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <span className="badge bg-orange-100 text-orange-800 text-xs">
                      {conflict.type}
                    </span>
                    <span className="text-xs text-gray-600">{formatDate(conflict.date)}</span>
                  </div>
                  <p className="text-sm text-gray-900 font-medium mb-1">{conflict.description}</p>
                  <p className="text-xs text-gray-600">Implicados: {conflict.involved.join(', ')}</p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">No hay conflictos activos</p>
          )}
        </div>
      </div>

      {/* Modal clima */}
      {showClimateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Registrar Clima</h2>
            <form onSubmit={handleAddClimate} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Nivel *</label>
                <select name="level" required className="select">
                  <option value="muy-positivo">Muy Positivo</option>
                  <option value="positivo">Positivo</option>
                  <option value="neutral">Neutral</option>
                  <option value="tenso">Tenso</option>
                  <option value="muy-tenso">Muy Tenso</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Notas</label>
                <textarea name="notes" rows={3} className="textarea" placeholder="Observaciones..."></textarea>
              </div>
              <div className="flex gap-3">
                <button type="submit" className="flex-1 btn btn-primary">Guardar</button>
                <button type="button" onClick={() => setShowClimateModal(false)} className="flex-1 btn btn-outline">Cancelar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal conflicto */}
      {showConflictModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-md w-full p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Registrar Conflicto</h2>
            <form onSubmit={handleAddConflict} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tipo *</label>
                <select name="type" required className="select">
                  <option value="disciplina">Disciplina</option>
                  <option value="convivencia">Convivencia</option>
                  <option value="familia">Familia</option>
                  <option value="rendimiento">Rendimiento</option>
                  <option value="otro">Otro</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Descripción *</label>
                <textarea name="description" rows={3} required className="textarea" placeholder="Describe el conflicto..."></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Implicados (separados por comas) *</label>
                <input type="text" name="involved" required className="input" placeholder="Ej: Juan, María" />
              </div>
              <div className="flex gap-3">
                <button type="submit" className="flex-1 btn btn-primary">Guardar</button>
                <button type="button" onClick={() => setShowConflictModal(false)} className="flex-1 btn btn-outline">Cancelar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
