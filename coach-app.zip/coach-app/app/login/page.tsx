// app/login/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { FaFutbol, FaEnvelope, FaLock } from 'react-icons/fa';
import { setUser, initializeMockData, generateAlerts } from '@/lib/storage';
import { User } from '@/lib/types';
import { generateId } from '@/lib/utils';

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    // Inicializar datos de ejemplo al cargar
    initializeMockData();
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Por favor completa todos los campos');
      return;
    }

    // Simulación de login simple
    const user: User = {
      id: generateId(),
      name: email.split('@')[0],
      email: email,
      role: 'coach',
      teamId: 'team-1',
    };

    setUser(user);
    generateAlerts();
    router.push('/dashboard');
  };

  const handleDemoLogin = () => {
    const demoUser: User = {
      id: 'demo-user',
      name: 'Entrenador Demo',
      email: 'demo@coachapp.com',
      role: 'coach',
      teamId: 'team-1',
    };

    setUser(demoUser);
    generateAlerts();
    router.push('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-secondary-50 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        {/* Logo y título */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center bg-primary-600 text-white rounded-full p-4 mb-4">
            <FaFutbol className="text-4xl" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Bienvenido a CoachApp
          </h1>
          <p className="text-gray-600">
            Inicia sesión para gestionar tu equipo
          </p>
        </div>

        {/* Formulario de login */}
        <div className="card">
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Correo electrónico
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaEnvelope className="text-gray-400" />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input pl-10"
                  placeholder="tu@email.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contraseña
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <FaLock className="text-gray-400" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input pl-10"
                  placeholder="••••••••"
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn btn-primary w-full text-lg"
            >
              Iniciar Sesión
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <button
              onClick={handleDemoLogin}
              className="btn btn-outline w-full"
            >
              Acceso Demo (Sin registro)
            </button>
            <p className="text-sm text-gray-500 text-center mt-3">
              Prueba la aplicación con datos de ejemplo
            </p>
          </div>
        </div>

        {/* Información adicional */}
        <div className="mt-8 text-center">
          <p className="text-sm text-gray-600">
            ¿No tienes cuenta?{' '}
            <button
              onClick={() => alert('Funcionalidad de registro disponible próximamente')}
              className="text-primary-600 font-medium hover:text-primary-700"
            >
              Regístrate aquí
            </button>
          </p>
        </div>

        {/* Volver al inicio */}
        <div className="mt-6 text-center">
          <button
            onClick={() => router.push('/')}
            className="text-gray-500 hover:text-gray-700 text-sm"
          >
            ← Volver al inicio
          </button>
        </div>
      </div>
    </div>
  );
}
