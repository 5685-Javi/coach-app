// app/stats/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { FaChartBar, FaUsers, FaClock, FaExclamationTriangle } from 'react-icons/fa';
import { getPlayers, getMatches, getAlerts, resolveAlert } from '@/lib/storage';
import { Player, Alert } from '@/lib/types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function StatsPage() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [stats, setStats] = useState({
    totalMinutes: 0,
    avgMinutes: 0,
    avgAttendance: 0,
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = () => {
    const allPlayers = getPlayers();
    const allAlerts = getAlerts().filter(a => !a.resolved);
    
    const totalMinutes = allPlayers.reduce((sum, p) => sum + p.totalMinutes, 0);
    const avgMinutes = allPlayers.length > 0 ? totalMinutes / allPlayers.length : 0;
    const avgAttendance = allPlayers.length > 0 
      ? allPlayers.reduce((sum, p) => sum + p.trainingAttendance, 0) / allPlayers.length 
      : 0;

    setPlayers(allPlayers);
    setAlerts(allAlerts);
    setStats({ totalMinutes, avgMinutes, avgAttendance });
  };

  const minutesData = players.map(p => ({
    name: p.name.split(' ')[0],
    minutos: p.totalMinutes,
  }));

  const positionData = ['Portero', 'Defensa', 'Centrocampista', 'Delantero'].map(pos => ({
    position: pos,
    count: players.filter(p => p.position === pos).length,
  }));

  const handleResolveAlert = (id: string) => {
    resolveAlert(id);
    loadStats();
  };

  return (
    <div className="space-y-6 fade-in">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Estadísticas</h1>
        <p className="text-gray-600 mt-1">Análisis de datos y métricas del equipo</p>
      </div>

      {/* Resumen */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card bg-gradient-to-br from-primary-500 to-primary-600 text-white">
          <FaClock className="text-3xl mb-3 text-primary-100" />
          <p className="text-primary-100 text-sm mb-1">Minutos Totales</p>
          <p className="text-4xl font-bold">{stats.totalMinutes}'</p>
        </div>
        <div className="card bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <FaUsers className="text-3xl mb-3 text-blue-100" />
          <p className="text-blue-100 text-sm mb-1">Media de Minutos</p>
          <p className="text-4xl font-bold">{Math.round(stats.avgMinutes)}'</p>
        </div>
        <div className="card bg-gradient-to-br from-green-500 to-green-600 text-white">
          <FaChartBar className="text-3xl mb-3 text-green-100" />
          <p className="text-green-100 text-sm mb-1">Asistencia Media</p>
          <p className="text-4xl font-bold">{Math.round(stats.avgAttendance * 100)}%</p>
        </div>
      </div>

      {/* Gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Minutos por Jugador</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={minutesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="minutos" fill="#22c55e" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Jugadores por Posición</h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={positionData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="position" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="count" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Alertas */}
      {alerts.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <FaExclamationTriangle className="text-orange-600 text-xl" />
            <h2 className="text-xl font-bold text-gray-900">Alertas Activas ({alerts.length})</h2>
          </div>
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert.id} className={`p-4 rounded-lg border ${
                alert.severity === 'critical' ? 'bg-red-50 border-red-200' :
                alert.severity === 'warning' ? 'bg-orange-50 border-orange-200' :
                'bg-blue-50 border-blue-200'
              }`}>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{alert.message}</p>
                    <p className="text-sm text-gray-500 mt-1">Tipo: {alert.type}</p>
                  </div>
                  <button
                    onClick={() => handleResolveAlert(alert.id)}
                    className="btn btn-sm bg-white text-gray-700 hover:bg-gray-100"
                  >
                    Resolver
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tabla de jugadores */}
      <div className="card">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Detalle por Jugador</h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Jugador</th>
                <th className="px-4 py-3 text-left text-sm font-semibold text-gray-900">Posición</th>
                <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">Minutos</th>
                <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">Asistencia</th>
                <th className="px-4 py-3 text-center text-sm font-semibold text-gray-900">Clima</th>
              </tr>
            </thead>
            <tbody>
              {players.map((player) => (
                <tr key={player.id} className="border-t border-gray-200">
                  <td className="px-4 py-3 text-sm text-gray-900">{player.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{player.position}</td>
                  <td className="px-4 py-3 text-sm text-center font-semibold text-gray-900">{player.totalMinutes}'</td>
                  <td className="px-4 py-3 text-sm text-center text-gray-900">{Math.round(player.trainingAttendance * 100)}%</td>
                  <td className="px-4 py-3 text-sm text-center">{player.climate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
