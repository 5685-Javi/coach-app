// app/page.tsx
'use client';

import { useRouter } from 'next/navigation';
import { FaFutbol, FaChartLine, FaBrain, FaUsers, FaBook, FaShieldAlt } from 'react-icons/fa';

export default function Home() {
  const router = useRouter();

  const features = [
    {
      icon: <FaUsers className="text-4xl text-primary-600" />,
      title: 'Gestión de Jugadores',
      description: 'Seguimiento completo: minutos, asistencia, desarrollo y clima personal.',
    },
    {
      icon: <FaFutbol className="text-4xl text-primary-600" />,
      title: 'Convocatorias y Partidos',
      description: 'Planifica convocatorias, gestiona minutos y analiza cada encuentro.',
    },
    {
      icon: <FaChartLine className="text-4xl text-secondary-600" />,
      title: 'Estadísticas y Alertas',
      description: 'Visualiza datos clave y recibe alertas sobre desequilibrios o riesgos.',
    },
    {
      icon: <FaBrain className="text-4xl text-secondary-600" />,
      title: 'IA Reflexiva',
      description: 'Asistente que te ayuda a pensar mejor, no a decidir por ti.',
    },
    {
      icon: <FaBook className="text-4xl text-primary-600" />,
      title: 'Diario del Entrenador',
      description: 'Registra aprendizajes, decisiones difíciles y mejora continua.',
    },
    {
      icon: <FaShieldAlt className="text-4xl text-secondary-600" />,
      title: 'Enfoque Ético',
      description: 'Protección del menor, uso responsable de datos y desarrollo integral.',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-white to-secondary-50">
      {/* Hero Section */}
      <header className="container mx-auto px-4 py-16 text-center">
        <div className="flex justify-center mb-6">
          <div className="bg-primary-600 text-white rounded-full p-6">
            <FaFutbol className="text-5xl" />
          </div>
        </div>
        
        <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-4">
          CoachApp
        </h1>
        
        <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
          La herramienta completa para entrenadores de fútbol formativo
        </p>
        
        <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto">
          Gestiona tu equipo con un enfoque que combina táctica, formación, psicología y ética. 
          Desarrolla personas, no solo jugadores.
        </p>
        
        <button
          onClick={() => router.push('/login')}
          className="btn btn-primary text-lg px-8 py-4 shadow-lg hover:shadow-xl"
        >
          Acceder a la Aplicación
        </button>
      </header>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">
          Características Principales
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="card-hover text-center fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-12">
            Nuestra Filosofía
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="card">
                <h3 className="text-xl font-bold text-primary-600 mb-3">
                  Formativo
                </h3>
                <p className="text-gray-700">
                  Priorizamos el desarrollo integral de cada jugador por encima de los resultados inmediatos.
                </p>
              </div>
              
              <div className="card">
                <h3 className="text-xl font-bold text-primary-600 mb-3">
                  Ético
                </h3>
                <p className="text-gray-700">
                  Protección del menor, uso responsable de datos y respeto por cada persona del equipo.
                </p>
              </div>
              
              <div className="card">
                <h3 className="text-xl font-bold text-secondary-600 mb-3">
                  Reflexivo
                </h3>
                <p className="text-gray-700">
                  Te ayudamos a pensar mejor sobre tus decisiones, no a tomar decisiones por ti.
                </p>
              </div>
              
              <div className="card">
                <h3 className="text-xl font-bold text-secondary-600 mb-3">
                  Práctico
                </h3>
                <p className="text-gray-700">
                  Resolvemos problemas reales del día a día de un entrenador de fútbol base.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Model T-F-P-E */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 mb-8">
          Modelo T-F-P-E
        </h2>
        
        <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
          Integramos cuatro dimensiones fundamentales en cada decisión y análisis
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
          <div className="card text-center border-t-4 border-blue-500">
            <h3 className="text-lg font-bold text-blue-600 mb-2">Táctico</h3>
            <p className="text-sm text-gray-600">Sistemas, posiciones y estrategia</p>
          </div>
          
          <div className="card text-center border-t-4 border-green-500">
            <h3 className="text-lg font-bold text-green-600 mb-2">Formativo</h3>
            <p className="text-sm text-gray-600">Desarrollo de habilidades y personas</p>
          </div>
          
          <div className="card text-center border-t-4 border-purple-500">
            <h3 className="text-lg font-bold text-purple-600 mb-2">Psicológico</h3>
            <p className="text-sm text-gray-600">Clima, confianza y motivación</p>
          </div>
          
          <div className="card text-center border-t-4 border-orange-500">
            <h3 className="text-lg font-bold text-orange-600 mb-2">Ético</h3>
            <p className="text-sm text-gray-600">Valores, justicia y respeto</p>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="bg-gradient-to-r from-primary-600 to-secondary-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            ¿Listo para mejorar tu forma de entrenar?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Únete a entrenadores que están transformando su manera de gestionar equipos
          </p>
          <button
            onClick={() => router.push('/login')}
            className="bg-white text-primary-600 px-8 py-4 rounded-lg text-lg font-bold hover:bg-gray-100 transition-all duration-200 shadow-lg hover:shadow-xl active:scale-95"
          >
            Comenzar Ahora
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            Proyecto desarrollado por Javi (13 años) - Enfoque formativo, ético y tecnológico
          </p>
          <p className="text-gray-500 text-sm mt-2">
            © 2026 CoachApp - Todos los derechos reservados
          </p>
        </div>
      </footer>
    </div>
  );
}
