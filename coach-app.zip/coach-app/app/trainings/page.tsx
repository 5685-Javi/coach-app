// app/trainings/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { FaPlus, FaDumbbell, FaTrash } from 'react-icons/fa';
import { getTrainings, addTraining, deleteTraining } from '@/lib/storage';
import { Training } from '@/lib/types';
import { generateId, formatDate } from '@/lib/utils';

export default function TrainingsPage() {
  const [trainings, setTrainings] = useState<Training[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState<Partial<Training>>({
    date: '',
    objectives: { tactical: [], formative: [] },
    tasks: [],
    attendance: [],
    teamId: 'team-1',
  });

  useEffect(() => {
    loadTrainings();
  }, []);

  const loadTrainings = () => {
    const all = getTrainings();
    setTrainings(all.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newTraining: Training = {
      id: generateId(),
      ...formData as Training,
    };
    addTraining(newTraining);
    loadTrainings();
    setShowModal(false);
  };

  return (
    <div className="space-y-6 fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Entrenamientos</h1>
          <p className="text-gray-600 mt-1">Planifica y registra sesiones de entrenamiento</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary flex items-center gap-2">
          <FaPlus /> Nuevo Entrenamiento
        </button>
      </div>

      {trainings.length > 0 ? (
        <div className="space-y-4">
          {trainings.map((training) => (
            <div key={training.id} className="card-hover">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <FaDumbbell className="text-green-600" />
                    <span className="text-sm text-gray-600">{formatDate(training.date)}</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {training.objectives.tactical[0] || 'Entrenamiento'}
                  </h3>
                  {training.objectives.tactical.length > 0 && (
                    <div className="mb-2">
                      <p className="text-sm font-medium text-gray-700">Objetivos tácticos:</p>
                      <p className="text-sm text-gray-600">{training.objectives.tactical.join(', ')}</p>
                    </div>
                  )}
                  {training.objectives.formative.length > 0 && (
                    <div>
                      <p className="text-sm font-medium text-gray-700">Objetivos formativos:</p>
                      <p className="text-sm text-gray-600">{training.objectives.formative.join(', ')}</p>
                    </div>
                  )}
                </div>
                <button
                  onClick={() => {
                    if (confirm('¿Eliminar entrenamiento?')) {
                      deleteTraining(training.id);
                      loadTrainings();
                    }
                  }}
                  className="btn bg-red-50 text-red-600 hover:bg-red-100"
                >
                  <FaTrash />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center py-12">
          <p className="text-gray-500 mb-4">No hay entrenamientos registrados</p>
          <button onClick={() => setShowModal(true)} className="btn btn-primary inline-flex items-center gap-2">
            <FaPlus /> Crear primer entrenamiento
          </button>
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Nuevo Entrenamiento</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Fecha *</label>
                  <input
                    type="datetime-local"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                    className="input"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Objetivos tácticos (separados por comas)</label>
                  <input
                    type="text"
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      objectives: { 
                        ...formData.objectives!, 
                        tactical: e.target.value.split(',').map(s => s.trim()).filter(Boolean) 
                      } 
                    })}
                    className="input"
                    placeholder="Ej: Presión alta, Salida de balón"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Objetivos formativos (separados por comas)</label>
                  <input
                    type="text"
                    onChange={(e) => setFormData({ 
                      ...formData, 
                      objectives: { 
                        ...formData.objectives!, 
                        formative: e.target.value.split(',').map(s => s.trim()).filter(Boolean) 
                      } 
                    })}
                    className="input"
                    placeholder="Ej: Trabajo en equipo, Comunicación"
                  />
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 btn btn-primary">Crear</button>
                  <button type="button" onClick={() => setShowModal(false)} className="flex-1 btn btn-outline">Cancelar</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
