// app/journal/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { FaBook, FaPlus } from 'react-icons/fa';
import { getJournalEntries, addJournalEntry } from '@/lib/storage';
import { JournalEntry, JournalType } from '@/lib/types';
import { generateId, formatDate } from '@/lib/utils';

export default function JournalPage() {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState<Partial<JournalEntry>>({
    type: 'reflexion',
    title: '',
    content: '',
    analysis: {},
    improvementCycle: [],
    teamId: 'team-1',
  });

  useEffect(() => {
    loadEntries();
  }, []);

  const loadEntries = () => {
    const all = getJournalEntries();
    setEntries(all.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const entry: JournalEntry = {
      id: generateId(),
      date: new Date().toISOString(),
      ...formData as JournalEntry,
    };
    
    addJournalEntry(entry);
    loadEntries();
    setShowModal(false);
    setFormData({
      type: 'reflexion',
      title: '',
      content: '',
      analysis: {},
      improvementCycle: [],
      teamId: 'team-1',
    });
  };

  const getTypeColor = (type: JournalType) => {
    const colors = {
      'partido': 'bg-blue-100 text-blue-800',
      'semana': 'bg-green-100 text-green-800',
      'decision': 'bg-orange-100 text-orange-800',
      'reflexion': 'bg-purple-100 text-purple-800',
    };
    return colors[type];
  };

  return (
    <div className="space-y-6 fade-in">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Diario del Entrenador</h1>
          <p className="text-gray-600 mt-1">Registra aprendizajes, decisiones y reflexiones</p>
        </div>
        <button onClick={() => setShowModal(true)} className="btn btn-primary flex items-center gap-2">
          <FaPlus /> Nueva Entrada
        </button>
      </div>

      {/* Información del modelo T-F-P-E */}
      <div className="card bg-gradient-to-r from-primary-50 to-secondary-50 border-2 border-primary-200">
        <h3 className="font-bold text-gray-900 mb-3">Modelo T-F-P-E de Análisis</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
          <div>
            <p className="font-semibold text-blue-700">Táctico</p>
            <p className="text-gray-600 text-xs">Sistemas, posiciones</p>
          </div>
          <div>
            <p className="font-semibold text-green-700">Formativo</p>
            <p className="text-gray-600 text-xs">Desarrollo, aprendizaje</p>
          </div>
          <div>
            <p className="font-semibold text-purple-700">Psicológico</p>
            <p className="text-gray-600 text-xs">Clima, motivación</p>
          </div>
          <div>
            <p className="font-semibold text-orange-700">Ético</p>
            <p className="text-gray-600 text-xs">Valores, justicia</p>
          </div>
        </div>
      </div>

      {/* Entradas del diario */}
      {entries.length > 0 ? (
        <div className="space-y-4">
          {entries.map((entry) => (
            <div key={entry.id} className="card">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className={`badge ${getTypeColor(entry.type)} text-xs`}>
                      {entry.type}
                    </span>
                    <span className="text-sm text-gray-500">{formatDate(entry.date)}</span>
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">{entry.title}</h3>
                </div>
                <FaBook className="text-2xl text-gray-400" />
              </div>

              <p className="text-gray-700 whitespace-pre-wrap mb-4">{entry.content}</p>

              {/* Análisis T-F-P-E */}
              {entry.analysis && Object.keys(entry.analysis).length > 0 && (
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <p className="font-semibold text-gray-900 mb-3 text-sm">Análisis T-F-P-E:</p>
                  <div className="space-y-2 text-sm">
                    {entry.analysis.tactical && (
                      <div>
                        <span className="font-medium text-blue-700">Táctico:</span>
                        <span className="text-gray-700 ml-2">{entry.analysis.tactical}</span>
                      </div>
                    )}
                    {entry.analysis.formative && (
                      <div>
                        <span className="font-medium text-green-700">Formativo:</span>
                        <span className="text-gray-700 ml-2">{entry.analysis.formative}</span>
                      </div>
                    )}
                    {entry.analysis.psychological && (
                      <div>
                        <span className="font-medium text-purple-700">Psicológico:</span>
                        <span className="text-gray-700 ml-2">{entry.analysis.psychological}</span>
                      </div>
                    )}
                    {entry.analysis.ethical && (
                      <div>
                        <span className="font-medium text-orange-700">Ético:</span>
                        <span className="text-gray-700 ml-2">{entry.analysis.ethical}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Ciclo de mejora */}
              {entry.improvementCycle && entry.improvementCycle.length > 0 && (
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="font-semibold text-purple-900 mb-2 text-sm">Ciclo de Mejora Continua:</p>
                  <div className="space-y-1 text-sm">
                    {entry.improvementCycle.map((cycle, idx) => (
                      <div key={idx}>
                        <span className="font-medium text-purple-700 capitalize">{cycle.phase}:</span>
                        <span className="text-gray-700 ml-2">{cycle.note}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="card text-center py-12">
          <p className="text-gray-500 mb-4">No hay entradas en el diario</p>
          <button onClick={() => setShowModal(true)} className="btn btn-primary inline-flex items-center gap-2">
            <FaPlus /> Crear primera entrada
          </button>
        </div>
      )}

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-xl max-w-3xl w-full my-8">
            <div className="p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Nueva Entrada en el Diario</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Tipo *</label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value as JournalType })}
                      className="select"
                    >
                      <option value="partido">Post-Partido</option>
                      <option value="semana">Semana</option>
                      <option value="decision">Decisión Difícil</option>
                      <option value="reflexion">Reflexión</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Título *</label>
                    <input
                      type="text"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      required
                      className="input"
                      placeholder="Ej: Partido vs Rival - Decisión sobre minutos"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Contenido *</label>
                  <textarea
                    value={formData.content}
                    onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                    required
                    rows={6}
                    className="textarea"
                    placeholder="Describe la situación, tus reflexiones, aprendizajes..."
                  />
                </div>

                <div className="border-t pt-4">
                  <p className="font-semibold text-gray-900 mb-3">Análisis T-F-P-E (opcional)</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-blue-700 mb-2">Táctico</label>
                      <input
                        type="text"
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          analysis: { ...formData.analysis, tactical: e.target.value } 
                        })}
                        className="input"
                        placeholder="Aspectos tácticos..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-green-700 mb-2">Formativo</label>
                      <input
                        type="text"
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          analysis: { ...formData.analysis, formative: e.target.value } 
                        })}
                        className="input"
                        placeholder="Aprendizajes formativos..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-purple-700 mb-2">Psicológico</label>
                      <input
                        type="text"
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          analysis: { ...formData.analysis, psychological: e.target.value } 
                        })}
                        className="input"
                        placeholder="Clima, motivación..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-orange-700 mb-2">Ético</label>
                      <input
                        type="text"
                        onChange={(e) => setFormData({ 
                          ...formData, 
                          analysis: { ...formData.analysis, ethical: e.target.value } 
                        })}
                        className="input"
                        placeholder="Valores, justicia..."
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button type="submit" className="flex-1 btn btn-primary">Guardar</button>
                  <button type="button" onClick={() => setShowModal(false)} className="flex-1 btn btn-outline">Cancelar</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
