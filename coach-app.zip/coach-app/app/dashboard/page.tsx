// app/dashboard/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { FaExclamationTriangle, FaUsers, FaCalendarAlt, FaDumbbell, FaChartLine, FaBell } from 'react-icons/fa';
import { getAlerts, getMatches, getTrainings, getPlayers, getTeam, generateAlerts } from '@/lib/storage';
import { Alert, Match, Training } from '@/lib/types';
import { formatDate } from '@/lib/utils';

export default function DashboardPage() {
  const router = useRouter();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [upcomingMatches, setUpcomingMatches] = useState<Match[]>([]);
  const [upcomingTrainings, setUpcomingTrainings] = useState<Training[]>([]);
  const [stats, setStats] = useState({
    totalPlayers: 0,
    totalMatches: 0,
    totalTrainings: 0,
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = () => {
    // Generar alertas
    generateAlerts();

    // Cargar alertas no resueltas
    const allAlerts = getAlerts();
    const unresolvedAlerts = allAlerts.filter(a => !a.resolved).slice(0, 5);
    setAlerts(unresolvedAlerts);

    // Cargar próximos partidos
    const matches = getMatches();
    const upcoming = matches
      .filter(m => new Date(m.date) >= new Date())
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 3);
    setUpcomingMatches(upcoming);

    // Cargar próximos entrenamientos
    const trainings = getTrainings();
    const upcomingT = trainings
      .filter(t => new Date(t.date) >= new Date())
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 3);
    setUpcomingTrainings(upcomingT);

    // Estadísticas generales
    const players = getPlayers();
    setStats({
      totalPlayers: players.length,
      totalMatches: matches.length,
      totalTrainings: trainings.length,
    });
  };

  const getSeverityIcon = (severity: string) => {
    if (severity === 'critical') return '🔴';
    if (severity === 'warning') return '⚠️';
    return 'ℹ️';
  };

  return (
    <div className="space-y-8 fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Vista general de tu equipo y próximas actividades</p>
      </div>

      {/* Tarjetas de estadísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="card bg-gradient-to-br from-primary-500 to-primary-600 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-primary-100 text-sm mb-1">Jugadores</p>
              <p className="text-3xl font-bold">{stats.totalPlayers}</p>
            </div>
            <FaUsers className="text-4xl text-primary-200" />
          </div>
        </div>

        <div className="card bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm mb-1">Partidos</p>
              <p className="text-3xl font-bold">{stats.totalMatches}</p>
            </div>
            <FaCalendarAlt className="text-4xl text-blue-200" />
          </div>
        </div>

        <div className="card bg-gradient-to-br from-green-500 to-green-600 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm mb-1">Entrenamientos</p>
              <p className="text-3xl font-bold">{stats.totalTrainings}</p>
            </div>
            <FaDumbbell className="text-4xl text-green-200" />
          </div>
        </div>

        <div className="card bg-gradient-to-br from-orange-500 to-orange-600 text-white cursor-pointer hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm mb-1">Alertas activas</p>
              <p className="text-3xl font-bold">{alerts.length}</p>
            </div>
            <FaBell className="text-4xl text-orange-200" />
          </div>
        </div>
      </div>

      {/* Alertas */}
      {alerts.length > 0 && (
        <div className="card border-l-4 border-orange-500">
          <div className="flex items-center gap-2 mb-4">
            <FaExclamationTriangle className="text-orange-500 text-xl" />
            <h2 className="text-xl font-bold text-gray-900">Alertas Activas</h2>
          </div>
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className={`p-4 rounded-lg border ${
                  alert.severity === 'critical'
                    ? 'bg-red-50 border-red-200'
                    : alert.severity === 'warning'
                    ? 'bg-orange-50 border-orange-200'
                    : 'bg-blue-50 border-blue-200'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-2xl">{getSeverityIcon(alert.severity)}</span>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{alert.message}</p>
                    <p className="text-sm text-gray-500 mt-1">{formatDate(alert.date)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <button
            onClick={() => router.push('/stats')}
            className="mt-4 text-primary-600 hover:text-primary-700 font-medium text-sm"
          >
            Ver todas las alertas →
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Próximos partidos */}
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <FaCalendarAlt className="text-primary-600 text-xl" />
            <h2 className="text-xl font-bold text-gray-900">Próximos Partidos</h2>
          </div>
          
          {upcomingMatches.length > 0 ? (
            <div className="space-y-3">
              {upcomingMatches.map((match) => (
                <div
                  key={match.id}
                  className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() => router.push(`/matches/${match.id}`)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-semibold text-gray-900">{match.rival}</p>
                    <span className="badge bg-blue-100 text-blue-800 text-xs">
                      {match.type}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">{formatDate(match.date)}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {match.location === 'local' ? '🏠 Local' : '✈️ Visitante'}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No hay partidos programados</p>
              <button
                onClick={() => router.push('/matches')}
                className="mt-3 text-primary-600 hover:text-primary-700 font-medium text-sm"
              >
                Crear partido
              </button>
            </div>
          )}
        </div>

        {/* Próximos entrenamientos */}
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <FaDumbbell className="text-green-600 text-xl" />
            <h2 className="text-xl font-bold text-gray-900">Próximos Entrenamientos</h2>
          </div>
          
          {upcomingTrainings.length > 0 ? (
            <div className="space-y-3">
              {upcomingTrainings.map((training) => (
                <div
                  key={training.id}
                  className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                  onClick={() => router.push(`/trainings/${training.id}`)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-semibold text-gray-900">
                      {training.objectives.tactical[0] || 'Entrenamiento'}
                    </p>
                  </div>
                  <p className="text-sm text-gray-600">{formatDate(training.date)}</p>
                  {training.objectives.tactical.length > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      Objetivos: {training.objectives.tactical.join(', ')}
                    </p>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <p>No hay entrenamientos programados</p>
              <button
                onClick={() => router.push('/trainings')}
                className="mt-3 text-primary-600 hover:text-primary-700 font-medium text-sm"
              >
                Crear entrenamiento
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Accesos rápidos */}
      <div className="card">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Accesos Rápidos</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            onClick={() => router.push('/players')}
            className="p-4 bg-primary-50 hover:bg-primary-100 rounded-lg transition-colors text-center"
          >
            <FaUsers className="text-2xl text-primary-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-900">Gestionar Jugadores</p>
          </button>
          
          <button
            onClick={() => router.push('/matches')}
            className="p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors text-center"
          >
            <FaCalendarAlt className="text-2xl text-blue-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-900">Crear Partido</p>
          </button>
          
          <button
            onClick={() => router.push('/stats')}
            className="p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors text-center"
          >
            <FaChartLine className="text-2xl text-green-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-900">Ver Estadísticas</p>
          </button>
          
          <button
            onClick={() => router.push('/journal')}
            className="p-4 bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors text-center"
          >
            <FaChartLine className="text-2xl text-purple-600 mx-auto mb-2" />
            <p className="text-sm font-medium text-gray-900">Escribir Diario</p>
          </button>
        </div>
      </div>
    </div>
  );
}
