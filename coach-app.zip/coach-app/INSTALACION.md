# 🚀 Guía de Instalación Rápida - CoachApp

## Requisitos Previos

- Node.js 18 o superior
- npm o yarn

## Instalación y Ejecución

### Opción 1: Instalación Local

```bash
# 1. Extraer el proyecto
unzip coach-app.zip
cd coach-app

# 2. Instalar dependencias
npm install

# 3. Ejecutar en modo desarrollo
npm run dev

# 4. Abrir en el navegador
# http://localhost:3000
```

### Opción 2: Build de Producción

```bash
# Después de instalar dependencias
npm run build
npm start

# La app estará disponible en http://localhost:3000
```

## Primer Uso

1. **Acceso**: Ve a `http://localhost:3000`
2. **Login**: Haz clic en "Acceso Demo (Sin registro)"
3. **Dashboard**: Explora la aplicación con datos de ejemplo pre-cargados

## Estructura del Proyecto

```
coach-app/
├── app/                 # Páginas y rutas
├── components/          # Componentes reutilizables
├── lib/                 # Lógica de negocio
│   ├── types/          # Tipos TypeScript
│   ├── storage/        # Sistema de almacenamiento
│   └── utils/          # Funciones auxiliares
├── public/             # Recursos estáticos
└── README.md           # Documentación completa
```

## Características Principales

✅ **Gestión de Jugadores** - CRUD completo con seguimiento
✅ **Partidos y Convocatorias** - Gestión de minutos y análisis
✅ **Entrenamientos** - Planificación con objetivos T-F-P-E
✅ **Clima y Conflictos** - Seguimiento del ambiente
✅ **Estadísticas con Gráficos** - Panel visual de datos
✅ **IA Reflexiva** - Asistente para pensar mejor
✅ **Diario del Entrenador** - Registro de aprendizajes
✅ **Sistema de Alertas** - Notificaciones automáticas
✅ **Configuración Personalizada** - Adapta la app a tu equipo

## Datos de Ejemplo

Al hacer login en modo demo, se cargan automáticamente:

- 5 jugadores con diferentes perfiles
- Configuración básica del equipo
- Alertas de ejemplo
- Sistema completo operativo

## Tecnologías

- **Next.js 14** - Framework React
- **TypeScript** - Tipado estático
- **Tailwind CSS** - Estilos
- **Recharts** - Gráficos
- **localStorage** - Almacenamiento local

## Navegación

Desde el navbar superior puedes acceder a:

- **Dashboard** - Vista general
- **Jugadores** - Gestión de plantilla
- **Partidos** - Convocatorias y resultados
- **Entrenos** - Planificación de sesiones
- **Clima** - Ambiente y conflictos
- **Estadísticas** - Análisis de datos
- **IA** - Asistente reflexivo
- **Diario** - Registro de aprendizajes
- **Ajustes** - Configuración

## Desarrollo

### Comandos disponibles

```bash
npm run dev      # Modo desarrollo (recomendado)
npm run build    # Build de producción
npm start        # Ejecutar build
npm run lint     # Linter
```

### Personalización

Puedes modificar:

- **Colores**: En `tailwind.config.js`
- **Estilos globales**: En `app/globals.css`
- **Tipos de datos**: En `lib/types/index.ts`
- **Lógica de almacenamiento**: En `lib/storage/index.ts`

## Troubleshooting

### Error: Puerto 3000 en uso

```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Mac/Linux
lsof -ti:3000 | xargs kill -9

# O usa otro puerto
PORT=3001 npm run dev
```

### Error: Módulos no encontrados

```bash
# Eliminar node_modules y reinstalar
rm -rf node_modules package-lock.json
npm install
```

### La app no guarda datos

- Los datos se guardan en localStorage del navegador
- Si borras caché/cookies, se pierden los datos
- Solución: Exporta los datos regularmente (función futura)

## Notas Importantes

⚠️ **Almacenamiento Local**: Los datos están en tu navegador. No uses en múltiples dispositivos sin exportar/importar.

⚠️ **Privacidad**: Ningún dato sale de tu ordenador. Todo es local.

⚠️ **Backup**: Considera hacer capturas de pantalla de datos importantes.

## Próximos Pasos

Una vez instalada y probada la app:

1. ✅ Configura tu equipo en **Ajustes**
2. ✅ Añade tus jugadores reales
3. ✅ Crea tu primer entrenamiento
4. ✅ Planifica tu próximo partido
5. ✅ Explora el módulo de IA
6. ✅ Escribe en tu diario

## Soporte

Esta es una aplicación educativa desarrollada por Javi (13 años).

Para más información, consulta el **README.md** completo.

---

¡Disfruta de CoachApp! 🏃⚽💚
