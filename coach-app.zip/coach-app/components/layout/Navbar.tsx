// components/layout/Navbar.tsx
'use client';

import { useRouter, usePathname } from 'next/navigation';
import { FaFutbol, FaUsers, FaCalendarAlt, FaDumbbell, FaCloudSun, FaChartBar, FaBrain, FaBook, FaCog, FaSignOutAlt, FaHome } from 'react-icons/fa';
import { getUser, setUser } from '@/lib/storage';
import { useEffect, useState } from 'react';

export default function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const [userName, setUserName] = useState('Usuario');

  useEffect(() => {
    const user = getUser();
    if (user) {
      setUserName(user.name);
    }
  }, []);

  const handleLogout = () => {
    setUser(null);
    router.push('/');
  };

  const menuItems = [
    { icon: <FaHome />, label: 'Dashboard', path: '/dashboard' },
    { icon: <FaUsers />, label: 'Jugadores', path: '/players' },
    { icon: <FaCalendarAlt />, label: 'Partidos', path: '/matches' },
    { icon: <FaDumbbell />, label: 'Entrenos', path: '/trainings' },
    { icon: <FaCloudSun />, label: 'Clima', path: '/climate' },
    { icon: <FaChartBar />, label: 'Estadísticas', path: '/stats' },
    { icon: <FaBrain />, label: 'IA', path: '/ai' },
    { icon: <FaBook />, label: 'Diario', path: '/journal' },
    { icon: <FaCog />, label: 'Ajustes', path: '/settings' },
  ];

  const isActive = (path: string) => pathname === path;

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => router.push('/dashboard')}>
            <div className="bg-primary-600 text-white rounded-lg p-2">
              <FaFutbol className="text-xl" />
            </div>
            <span className="font-bold text-xl text-gray-900">CoachApp</span>
          </div>

          {/* Menu Desktop */}
          <div className="hidden lg:flex items-center gap-1">
            {menuItems.map((item) => (
              <button
                key={item.path}
                onClick={() => router.push(item.path)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                  isActive(item.path)
                    ? 'bg-primary-50 text-primary-600 font-medium'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {item.icon}
                <span className="text-sm">{item.label}</span>
              </button>
            ))}
          </div>

          {/* Usuario y logout */}
          <div className="flex items-center gap-3">
            <div className="hidden md:block text-right">
              <p className="text-sm font-medium text-gray-900">{userName}</p>
              <p className="text-xs text-gray-500">Entrenador</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-all duration-200"
              title="Cerrar sesión"
            >
              <FaSignOutAlt />
              <span className="hidden sm:inline text-sm">Salir</span>
            </button>
          </div>
        </div>

        {/* Menu Mobile */}
        <div className="lg:hidden pb-3 overflow-x-auto">
          <div className="flex gap-2">
            {menuItems.map((item) => (
              <button
                key={item.path}
                onClick={() => router.push(item.path)}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg whitespace-nowrap transition-all duration-200 text-sm ${
                  isActive(item.path)
                    ? 'bg-primary-50 text-primary-600 font-medium'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </nav>
  );
}
